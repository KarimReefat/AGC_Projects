﻿Public Class Form2

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        ' check if the text boxes have data in it if not stop execute the rest of the code
        If check_text_in_box(GroupBox1) Then
            Exit Sub
        End If

        ' declare ths select statement as strin for the employees table
        Dim employee As String = "SELECt * From Employees Where UserName = '" +
            TextBox1.Text + "'" + "and Password = '" + TextBox2.Text + "'"

        ' declare ths select statement as strin for the customers table
        Dim customer As String = "SELECt * From Customers Where User_Name = '" +
            TextBox1.Text + "'" + " and Password = '" + TextBox2.Text + "'"

        ' make select with the label1 text it it's customer loging then we run the customer form
        If Label1.Text = "Customer LogIn" Then

            ' choose the connection and it's type and the select text
            comm.CommandType = CommandType.Text
            comm.CommandText = customer
            comm.Connection = conn

            ' open the connection
            conn.Open()

            ' execute the reader to get the customer data
            reader = comm.ExecuteReader()

            ' checking to see if the there is no record it mean no customer with this data
            If reader.Read() = False Then

                ' fire a message box 
                MsgBox("Not Found")

                ' close the reader 
                reader.Close()

                ' close the connection
                conn.Close()
                Exit Sub
            End If

            ' if not it mean he found the customer data so he change the customer form 

            ' text to the customer user name
            Form4.Text = reader("User_name")

            ' take the customer id and put it in the global_customer_id public variable 
            ' in order to use it after that to get the customer account balance
            global_customer_id = reader("ID")

            ' close the reader
            reader.Close()

            ' close the connection
            conn.Close()

            ' show the customer form
            Form4.ShowDialog()

            ' else then he choose an employee log in 
        ElseIf Label1.Text = "Employee LogIn" Then

            ' choose the connection and it's type and the select text
            comm.CommandType = CommandType.Text
            comm.CommandText = employee
            comm.Connection = conn

            ' open the connection
            conn.Open()

            ' execute the reader to get the employee data
            reader = comm.ExecuteReader()

            ' checking to see if the there is no record it mean no employee with this data
            If reader.Read() = False Then

                ' fire a message box 
                MsgBox("Not Found")

                ' close the reader 
                reader.Close()

                ' close the connection
                conn.Close()
                Exit Sub
            End If

            ' if not it mean he found the employee data so he change the employee form 

            ' text to the employee user name
            Form3.Label2.Text = reader("UserName")

            ' close the reader 
            reader.Close()

            ' close the connection
            conn.Close()

            ' show the employee form
            Form3.ShowDialog()
        End If

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        ' when press cancel button it close the current form and go back to the main form
        Me.Dispose()

    End Sub
End Class