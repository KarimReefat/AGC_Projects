﻿Imports System.Data
Imports System.Data.SqlClient

Module Module1
    Public global_user_name As String
    Public global_customer_id As String

    Public conn As New SqlConnection(
    "Data Source=KARIM-PC\SQLEXPRESS;Initial Catalog=ATM;User ID=ahmed;Password=123")
    Public comm As New SqlCommand
    Public reader As SqlDataReader
    Public adapt As New SqlDataAdapter
    Public dbs As New DataSet
    Public table As New DataTable

    'الدالة المسئولة عن عملية مسح مربعات النص من داخل الفورم 
    Public Sub clear_text_in_box(ByVal gr As Form)
        Dim c As Control
        'يتم عمل حلقة بداخلها الادوات الموجودة علي اداة الجروب بوكس ويتم فحص نوعها 
        ' اذا كانت من النوع مربع النص يتم تفريغ النصوص التى بداخلها 
        For Each c In gr.Controls
            If TypeOf (c) Is TextBox Then
                c.Text = ""
            End If
        Next
    End Sub

    'الدالة المسئولة عن عملية مسح مربعات النص من داخل الفورم 
    Public Sub clear_text_in_box(ByVal gr As GroupBox)
        Dim c As Control
        'يتم عمل حلقة بداخلها الادوات الموجودة علي اداة الجروب بوكس ويتم فحص نوعها 
        ' اذا كانت من النوع مربع النص يتم تفريغ النصوص التى بداخلها 
        For Each c In gr.Controls
            If TypeOf (c) Is TextBox Then
                c.Text = ""
            End If
        Next
    End Sub

    'الدالة المسئولة عن فحص مربعات النص والتأكد من وجود بيانات بداخلها 
    Public Function check_text_in_box(ByVal gr As Form) As Boolean
        Dim c As Control
        'يتم عمل حلقة بداخلها الادوات الموجودة علي اداة الجروب بوكس ويتم فحص نوعها 
        ' اذا كانت من النوع مربع النص يتم التأكد من اذا كانت خالية من النصوص
        'في تلك الحالة تظهر رسالة تذكر اسم مربع النص وتذكر انه خالي من البيانات 

        For Each c In gr.Controls
            If TypeOf (c) Is TextBox Then
                If c.Text = "" Then
                    MsgBox(c.Name & Space(2) & "Is Empty")
                    c.Select()
                    Return True
                End If
            End If
        Next
        Return False
    End Function


    'الدالة المسئولة عن فحص مربعات النص والتأكد من وجود بيانات بداخلها 
    Public Function check_text_in_box(ByVal gr As GroupBox) As Boolean
        Dim c As Control
        'يتم عمل حلقة بداخلها الادوات الموجودة علي اداة الجروب بوكس ويتم فحص نوعها 
        ' اذا كانت من النوع مربع النص يتم التأكد من اذا كانت خالية من النصوص
        'في تلك الحالة تظهر رسالة تذكر اسم مربع النص وتذكر انه خالي من البيانات 

        For Each c In gr.Controls
            If TypeOf (c) Is TextBox Then
                If c.Text = "" Then
                    MsgBox(c.Name & Space(2) & "Is Empty")
                    c.Select()
                    Return True
                End If
            End If
        Next
        Return False
    End Function
End Module
