﻿Public Class Form4

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        ' acitvate the deposists groupbox and deactivate the withdrawals groupbox
        GroupBox2.Enabled = True
        GroupBox3.Enabled = False

        ' take the current customer id and put it in the textbox inside the groupbox
        TextBox1.Text = global_customer_id

        ' put the current date in the date box event i will not going to use it inside the table
        TextBox2.Text = Date.Now.ToString()

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click

        ' acitvate the withdrawals groupbox and deactivate the deposists groupbox
        GroupBox3.Enabled = True
        GroupBox2.Enabled = False

        ' take the current customer id and put it in the textbox inside the groupbox
        TextBox8.Text = global_customer_id

        ' put the current date in the date box event i will not going to use it inside the table
        TextBox7.Text = Date.Now.ToString()

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        ' close the customer form and return to the main form
        Me.Dispose()

    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click

        ' clear the textboxes from the withdrawals groupbox
        TextBox6.Text = ""
        TextBox7.Text = ""
        TextBox8.Text = ""
        TextBox5.Text = ""

        ' disable the withdrwals groupbox
        GroupBox3.Enabled = False

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click

        ' clear the textboxes from the deposits groupbox
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""


        ' disable the deposits groupbox
        GroupBox2.Enabled = False

    End Sub

    Private Sub Form4_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ' this code will be execute after the load of the form 
        ' the code for geting the total amount of money in the customer accont
        comm.CommandType = CommandType.Text
        comm.Connection = conn

        ' after choose the connection and the type of the command we send the command text
        ' and this case i am going to call a sql server function and it's name is GetBalance
        ' the way of calling a function inside the sql sever database it's self is first by
        ' add a paramenters this parameter will take the value from the gloabal_customer_id 
        ' or it will take teh value from the previous form after the customer log in and after
        ' that it will send this parameter to the funciton inside the sql server database and 
        ' the function will return with the total amount the customer have in his account
        comm.CommandText = "select dbo.GetBalance(@id)"
        comm.Parameters.Add("@id", global_customer_id)

        ' open the connection with the database
        conn.Open()

        ' in this case becuse i want to have the data that the function is return with i have to 
        ' choose the ExecuteScalar command from the command ojbect and it will give me the 
        ' return value from the function and i put it inside the a vairable
        Dim a As Integer = comm.ExecuteScalar()

        ' send the total customer amount in his acount to the textbox
        TextBox9.Text = a

        ' clear the parameters from the command and i must use this command becuse if i try 
        ' to load the form once again it will give me an error becuse i have add a parameter
        ' with out first delete the previous one so i use this command to clear all the 
        ' parameters from the command object
        comm.Parameters.Clear()

        ' close the connection with the database
        conn.Close()
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click

        ' this is the withdarwals button to add the money to the account

        ' first check if the groupbox have any empty textboxes if it will show it's name
        ' and stop execute the rest of the code
        If check_text_in_box(GroupBox3) Then
            Exit Sub
        End If

        ' the calling of the sotred procedure inside the sql server database and the way for calling
        ' the stored procedure is first by choose the type of the command and in this case it will
        ' be stored procedure and choose the connection to the database and in this case the 
        ' command text will be only the name of the procedure
        comm.CommandType = CommandType.StoredProcedure
        comm.Connection = conn
        comm.CommandText = "AddWithdrawals"

        ' next i add the parameters that goging to have the value that i am going to send to 
        ' the proecudre and there is one vey important note in here that the parameters 
        ' you goging to add to the command must have the same name to the parameters inside 
        ' the stored procedure so you must choose the same name in order to the command to find it
        comm.Parameters.Add("@AccNo", global_customer_id)
        comm.Parameters.Add("@Amount", TextBox5.Text)
        comm.Parameters.Add("@Details", TextBox6.Text)
        comm.Parameters.Add("@EmpUserName", "None")

        ' next open the connection with the database
        conn.Open()

        ' next i will exeucte the non query command and take the return value and put it 
        ' inside the vairable to print and this return value is the one the procedure going to
        ' return with like if i call it from inside the sql server
        Dim a As Integer = comm.ExecuteNonQuery()

        ' showing the message of the return value from the procedure  
        MsgBox(a.ToString() & " Record Add")

        ' clear the parameters list after that 
        comm.Parameters.Clear()

        ' close the connenction with the database
        conn.Close()

        ' clear all the textboxes from text 
        clear_text_in_box(GroupBox3)

        ' activate the current form load event to the get me the customer total amount of 
        ' money that he have inside his account
        Form4_Load(sender, e)

        ' return back the customer id to the textexbox in order to use it again 
        TextBox8.Text = global_customer_id

        ' return back the current date to the textexbox in order to use it again
        TextBox7.Text = Date.Now.ToString()

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click

        ' this is the deposits button to add the money to the account

        ' first check if the groupbox have any empty textboxes if it will show it's name
        ' and stop execute the rest of the code
        If check_text_in_box(GroupBox2) Then
            Exit Sub
        End If

        ' the calling of the sotred procedure inside the sql server database and the way for calling
        ' the stored procedure is first by choose the type of the command and in this case it will
        ' be stored procedure and choose the connection to the database and in this case the 
        ' command text will be only the name of the procedure
        comm.CommandType = CommandType.StoredProcedure
        comm.Connection = conn
        comm.CommandText = "AddDeposit"

        ' next i add the parameters that goging to have the value that i am going to send to 
        ' the proecudre and there is one vey important note in here that the parameters 
        ' you goging to add to the command must have the same name to the parameters inside 
        ' the stored procedure so you must choose the same name in order to the command to find it
        comm.Parameters.Add("@AccNo", global_customer_id)
        comm.Parameters.Add("@Amount", TextBox4.Text)
        comm.Parameters.Add("@Details", TextBox3.Text)
        comm.Parameters.Add("@EmpUserName", "None")

        ' next open the connection with the database
        conn.Open()

        ' next i will exeucte the non query command and take the return value and put it 
        ' inside the vairable to print and this return value is the one the procedure going to
        ' return with like if i call it from inside the sql server
        Dim a As Integer = comm.ExecuteNonQuery()

        ' showing the message of the return value from the procedure 
        MsgBox(a.ToString() & " Record Add")

        ' clear the parameters list after that
        comm.Parameters.Clear()

        ' close the connenction with the database
        conn.Close()

        ' clear all the textboxes from text 
        clear_text_in_box(GroupBox2)

        ' activate the current form load event to the get me the customer total amount of 
        ' money that he have inside his account
        Form4_Load(sender, e)

        ' return back the customer id to the textexbox in order to use it again 
        TextBox1.Text = global_customer_id

        ' return back the current date to the textexbox in order to use it again
        TextBox2.Text = Date.Now.ToString()

    End Sub
End Class