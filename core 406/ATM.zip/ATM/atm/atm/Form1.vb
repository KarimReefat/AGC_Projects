﻿Public Class Form1

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click

        ' ending the porgram
        End

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        ' change the main label to be employee loging
        Form2.Label1.Text = "Employee LogIn"

        ' change the form text to be employee loging
        Form2.Text = "Employee LogIn"

        ' showing form2 
        Form2.ShowDialog()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        ' change the main label to be employee loging

        Form2.Label1.Text = "Customer LogIn"

        ' change the form text to be customer loging
        Form2.Text = "Customer LogIn"

        ' showing form2 
        Form2.ShowDialog()

    End Sub
End Class
