﻿Public Class Form3

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        ' pressing the new key he first clear all the text boxes
        clear_text_in_box(Me)

        ' choose the connection for the command
        comm.Connection = conn

        ' choose the command type and in this case it will text
        comm.CommandType = CommandType.Text

        ' choose the command text and here i will select the count select statmentment
        ' in order to get the total record in the customers table so that i know what
        ' is the new customer number in the table record is
        comm.CommandText = "select count(id) from customers"

        ' open the connection
        conn.Open()

        ' execute the command and put the data in the reader
        reader = comm.ExecuteReader()

        ' read the data from the reader
        reader.Read()

        ' get the number of the customers and add one to it this will be the new 
        ' customer number and put it in it's textbox
        TextBox1.Text = reader(0) + 1

        ' close the connection
        conn.Close()

        ' close the reader in order to use them after that
        reader.Close()

        ' activate the save button
        Button2.Enabled = True

    End Sub

    Private Sub Form3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ' disable the save button in the form load
        Button2.Enabled = False

        ' disable the edit button in the form load
        Button4.Enabled = False

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        ' declare the variable that will be use in the select statment 
        Dim a, b, name, job, phone, mobile, email, city, address, user_name, password As String

        ' assing the variable with it's value from the textboxes in the form
        a = "'"
        b = "',"
        name = a + TextBox2.Text + b
        job = a + TextBox3.Text + b
        phone = a + TextBox4.Text + b
        mobile = a + TextBox5.Text + b
        email = a + TextBox6.Text + b
        city = a + TextBox7.Text + b
        address = a + TextBox8.Text + b
        user_name = a + TextBox9.Text + b
        password = a + TextBox10.Text + a

        ' check if there is any empty text boxes if so the code with be stop after 
        ' the empty textbox will be selected and after that it will show a messagebox
        ' telling the name of the empty textboxes
        If check_text_in_box(Me) Then
            Exit Sub
        End If

        ' the select statment of the insert new customers data and it use the upper variabless
        Dim new_customer As String = "Insert into customers (sname, job, phone, mobile, email, city, address, user_name, password) values (" +
            name + job + phone + mobile + email + city + address + user_name + password + ")"

        ' choose the connection and it's type and the command text 
        comm.CommandType = CommandType.Text
        comm.CommandText = new_customer
        comm.Connection = conn

        ' open the connection
        conn.Open()

        ' exeucte the insert command and save the return records number in the variable
        Dim h As Integer = comm.ExecuteNonQuery()

        ' a message box show the effected record
        MsgBox(h.ToString() + " Records save")

        ' close the connection
        conn.Close()

        ' empty the textboxes after saveing the new data customer
        clear_text_in_box(Me)

        ' diable the save button after that
        Button2.Enabled = False

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click

        ' the search button

        ' showing inputbox to the employee to enter it's customer user name
        Dim x As String
        x = InputBox("Enter the User Name ")

        ' the select statment searching for the customer user name 
        comm.CommandText = "select * from customers where user_name='" + x + "'"

        ' open the connection with the database
        conn.Open()

        ' execute the command and put the result in the datareader
        reader = comm.ExecuteReader

        ' exute the read fucntion in the datareader
        reader.Read()

        ' if there is no rows in the reader it mean he didn't found the customer user name
        If reader.HasRows = False Then

            ' showing message box and then close the reader and the connection with the database
            MsgBox("Not Found")
            reader.Close()
            conn.Close()
            Exit Sub
        End If

        ' else he found the customer user name so it take his information and put it in textboxes
        TextBox1.Text = reader("id")
        TextBox2.Text = reader("sname")
        TextBox3.Text = reader("job")
        TextBox4.Text = reader("phone")
        TextBox5.Text = reader("mobile")
        TextBox6.Text = reader("email")
        TextBox7.Text = reader("city")
        TextBox8.Text = reader("address")
        TextBox9.Text = reader("user_name")
        TextBox10.Text = reader("password")

        ' sending the customer user name and id to the global variable global_user_name 
        ' and to global_customer_id in order to use it after that in calling the customer
        ' balance to know his current account money state
        global_user_name = reader("user_name")
        global_customer_id = reader("ID")

        ' close the reader 
        reader.Close()

        ' close the connection
        conn.Close()

        ' open the edit button if we want to make change to the customer information
        Button4.Enabled = True

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click

        ' the edit button the edit the customer data

        ' first we make variables to take the customers data from the textboxes
        ' after calling the customer user name from the search button
        Dim a, b, name, job, phone, mobile, email, city, address, user_name, password As String
        a = "'"
        b = "',"
        name = a + TextBox2.Text + b
        job = a + TextBox3.Text + b
        phone = a + TextBox4.Text + b
        mobile = a + TextBox5.Text + b
        email = a + TextBox6.Text + b
        city = a + TextBox7.Text + b
        address = a + TextBox8.Text + b
        user_name = a + TextBox9.Text + b
        password = a + TextBox10.Text + a

        ' after that i make choore that every text box have data in it if not it will
        ' select the empty textbox and showing message of it's name and then stop the
        ' rest of the code
        If check_text_in_box(Me) Then
            Exit Sub
        End If

        ' the update statment take the variable that has the customer new data in it
        ' and select the customer by his id and when i first make this program i choose 
        ' that the select by the customer user name but after a while i choose to make 
        ' it by the customer id becuse we chould have a more than on customer with the 
        ' same user name but there will be no more than one customer with the same id
        Dim edit_customer As String = "UPDATE customers SET sname =" + name + " job = " + job +
            "phone = " + phone + "mobile = " + mobile + "email = " + email + "city = " + city +
            "address = " + address + "user_name = " + user_name + "password = " + password +
            " Where ID = '" + global_customer_id + "'"

        ' choose the command type and text and the connection and open the connection
        comm.CommandType = CommandType.Text
        comm.CommandText = edit_customer
        comm.Connection = conn
        conn.Open()

        ' execute the command and save the return records that get efect by the select
        ' and save the number in variable to show it in message box
        Dim h As Integer = comm.ExecuteNonQuery()
        MsgBox(h.ToString() + " record edit ")

        ' close the connection
        conn.Close()

        ' clear all the form textbox from former text
        clear_text_in_box(Me)

        ' disable the edit button after finshing
        Button4.Enabled = False

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click

        ' show the show all form to show all the customer in the customer tables
        Form5.ShowDialog()

    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click

        ' the back button when we click it it close the employee form and return the log in form
        Me.Dispose()

    End Sub
End Class