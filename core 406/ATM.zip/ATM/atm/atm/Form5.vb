﻿Public Class Form5

    Private Sub Form5_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ' connect the command to the connecion 
        comm.Connection = conn

        ' choose the type of command and in this case it will be text 
        comm.CommandType = CommandType.Text

        ' the select statment and it will give ust all the record in the customers table
        comm.CommandText = "SELECT * FROM Customers"

        ' open the connection with database
        conn.Open()

        ' connecting the adapter with the command ojbect
        adapt.SelectCommand = comm

        ' geting the data coming from the command object and puting it in the dataset and call it customers
        adapt.Fill(dbs, "Customers")

        ' connecting the data inside the dataset to the table object table
        table = dbs.Tables("Customers")

        ' connect the table object with the datgridview in order to show all the record of the customers
        DataGridView1.DataSource = table

        ' close the connection with the database after finshing in ordder to use it in other places
        conn.Close()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ' the code to clear the table from all it's rows in order to clear the datagrid
        table.Clear()

        ' it's close the current form and return back to the embloyee form
        Me.Dispose()

    End Sub
End Class