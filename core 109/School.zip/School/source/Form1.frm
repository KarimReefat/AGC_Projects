VERSION 5.00
Object = "{00028C01-0000-0000-0000-000000000046}#1.0#0"; "DBGRID32.OCX"
Begin VB.Form Form1 
   Caption         =   "������� �������"
   ClientHeight    =   5310
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   6780
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   RightToLeft     =   -1  'True
   ScaleHeight     =   5310
   ScaleWidth      =   6780
   StartUpPosition =   2  'CenterScreen
   Begin VB.Frame Frame4 
      Height          =   3390
      Left            =   90
      RightToLeft     =   -1  'True
      TabIndex        =   50
      Top             =   765
      Width           =   6585
      Begin VB.CommandButton Command19 
         Caption         =   "��� "
         Height          =   510
         Left            =   5040
         RightToLeft     =   -1  'True
         TabIndex        =   59
         Top             =   2745
         Visible         =   0   'False
         Width           =   1320
      End
      Begin VB.TextBox Text18 
         Alignment       =   1  'Right Justify
         Height          =   375
         Left            =   3690
         RightToLeft     =   -1  'True
         TabIndex        =   56
         Top             =   2925
         Visible         =   0   'False
         Width           =   960
      End
      Begin VB.TextBox Text17 
         Alignment       =   1  'Right Justify
         Height          =   375
         Left            =   2565
         RightToLeft     =   -1  'True
         TabIndex        =   55
         Top             =   2925
         Visible         =   0   'False
         Width           =   960
      End
      Begin VB.CommandButton Command18 
         Caption         =   "����"
         Height          =   555
         Left            =   270
         RightToLeft     =   -1  'True
         TabIndex        =   54
         Top             =   2700
         Width           =   1860
      End
      Begin VB.Data Data2 
         Caption         =   "Data2"
         Connect         =   "Access 2000;"
         DatabaseName    =   "School.mdb"
         DefaultCursorType=   0  'DefaultCursor
         DefaultType     =   2  'UseODBC
         Exclusive       =   0   'False
         Height          =   465
         Left            =   135
         Options         =   0
         ReadOnly        =   0   'False
         RecordsetType   =   1  'Dynaset
         RecordSource    =   ""
         RightToLeft     =   -1  'True
         Top             =   2115
         Width           =   6360
      End
      Begin MSDBGrid.DBGrid DBGrid1 
         Bindings        =   "Form1.frx":0000
         Height          =   1815
         Left            =   135
         OleObjectBlob   =   "Form1.frx":0014
         TabIndex        =   51
         Top             =   225
         Width           =   6360
      End
      Begin VB.Label Label18 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "����� ������:"
         Height          =   195
         Left            =   2700
         RightToLeft     =   -1  'True
         TabIndex        =   58
         Top             =   2655
         Visible         =   0   'False
         Width           =   840
      End
      Begin VB.Label Label17 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "����� �����:"
         Height          =   195
         Left            =   3870
         RightToLeft     =   -1  'True
         TabIndex        =   57
         Top             =   2655
         Visible         =   0   'False
         Width           =   750
      End
   End
   Begin VB.Frame Frame2 
      Caption         =   "������ ������"
      Height          =   3705
      Left            =   1170
      RightToLeft     =   -1  'True
      TabIndex        =   7
      Top             =   315
      Width           =   4020
      Begin VB.CommandButton Command11 
         Caption         =   "����"
         Height          =   375
         Left            =   675
         RightToLeft     =   -1  'True
         TabIndex        =   28
         Top             =   2745
         Width           =   1140
      End
      Begin VB.CommandButton Command10 
         Caption         =   "�������"
         Height          =   375
         Left            =   1935
         RightToLeft     =   -1  'True
         TabIndex        =   27
         Top             =   2745
         Width           =   1140
      End
      Begin VB.CommandButton Command9 
         Caption         =   "���"
         Height          =   375
         Left            =   135
         RightToLeft     =   -1  'True
         TabIndex        =   26
         Top             =   2250
         Width           =   1140
      End
      Begin VB.CommandButton Command8 
         Caption         =   "���"
         Height          =   375
         Left            =   1395
         RightToLeft     =   -1  'True
         TabIndex        =   25
         Top             =   2250
         Width           =   1140
      End
      Begin VB.CommandButton Command7 
         Caption         =   "����"
         Height          =   375
         Left            =   2610
         RightToLeft     =   -1  'True
         TabIndex        =   24
         Top             =   2250
         Width           =   1140
      End
      Begin VB.Data Data1 
         Caption         =   "Data1"
         Connect         =   "Access 2000;"
         DatabaseName    =   "School.mdb"
         DefaultCursorType=   0  'DefaultCursor
         DefaultType     =   2  'UseODBC
         Exclusive       =   0   'False
         Height          =   375
         Left            =   180
         Options         =   0
         ReadOnly        =   0   'False
         RecordsetType   =   1  'Dynaset
         RecordSource    =   "Students"
         RightToLeft     =   -1  'True
         Top             =   3195
         Width           =   3660
      End
      Begin VB.TextBox Text8 
         Alignment       =   1  'Right Justify
         Appearance      =   0  'Flat
         DataField       =   "Z"
         DataSource      =   "Data1"
         Height          =   330
         Left            =   495
         Locked          =   -1  'True
         RightToLeft     =   -1  'True
         TabIndex        =   15
         Text            =   "Text1"
         Top             =   1845
         Width           =   1005
      End
      Begin VB.TextBox Text7 
         Alignment       =   1  'Right Justify
         Appearance      =   0  'Flat
         DataField       =   "Y"
         DataSource      =   "Data1"
         Height          =   330
         Left            =   1530
         Locked          =   -1  'True
         RightToLeft     =   -1  'True
         TabIndex        =   14
         Text            =   "Text1"
         Top             =   1845
         Width           =   1005
      End
      Begin VB.TextBox Text6 
         Alignment       =   1  'Right Justify
         Appearance      =   0  'Flat
         DataField       =   "X"
         DataSource      =   "Data1"
         Height          =   330
         Left            =   2565
         Locked          =   -1  'True
         RightToLeft     =   -1  'True
         TabIndex        =   13
         Text            =   "Text1"
         Top             =   1845
         Width           =   1005
      End
      Begin VB.TextBox Text5 
         Alignment       =   1  'Right Justify
         Appearance      =   0  'Flat
         DataField       =   "Ph"
         DataSource      =   "Data1"
         Height          =   330
         Left            =   495
         RightToLeft     =   -1  'True
         TabIndex        =   12
         Text            =   "Text1"
         Top             =   1215
         Width           =   1005
      End
      Begin VB.TextBox Text4 
         Alignment       =   1  'Right Justify
         Appearance      =   0  'Flat
         DataField       =   "Gr"
         DataSource      =   "Data1"
         Height          =   330
         Left            =   1530
         RightToLeft     =   -1  'True
         TabIndex        =   11
         Text            =   "Text1"
         Top             =   1215
         Width           =   1005
      End
      Begin VB.TextBox Text3 
         Alignment       =   1  'Right Justify
         Appearance      =   0  'Flat
         DataField       =   "Id"
         DataSource      =   "Data1"
         Height          =   330
         Left            =   2565
         RightToLeft     =   -1  'True
         TabIndex        =   10
         Text            =   "Text1"
         Top             =   1215
         Width           =   1005
      End
      Begin VB.TextBox Text2 
         Alignment       =   1  'Right Justify
         Appearance      =   0  'Flat
         DataField       =   "ADDR"
         DataSource      =   "Data1"
         Height          =   330
         Left            =   90
         RightToLeft     =   -1  'True
         TabIndex        =   9
         Text            =   "Text1"
         Top             =   540
         Width           =   3300
      End
      Begin VB.TextBox Text1 
         Alignment       =   1  'Right Justify
         Appearance      =   0  'Flat
         DataField       =   "SName"
         DataSource      =   "Data1"
         Height          =   330
         Left            =   90
         RightToLeft     =   -1  'True
         TabIndex        =   8
         Text            =   "Text1"
         Top             =   180
         Width           =   3300
      End
      Begin VB.Label Label8 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "������ �������"
         Height          =   195
         Left            =   675
         RightToLeft     =   -1  'True
         TabIndex        =   23
         Top             =   1620
         Width           =   825
      End
      Begin VB.Label Label7 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "������ �������"
         Height          =   195
         Left            =   1710
         RightToLeft     =   -1  'True
         TabIndex        =   22
         Top             =   1620
         Width           =   840
      End
      Begin VB.Label Label6 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "������ ������"
         Height          =   195
         Left            =   2700
         RightToLeft     =   -1  'True
         TabIndex        =   21
         Top             =   1620
         Width           =   855
      End
      Begin VB.Label Label5 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "��� ��������"
         Height          =   195
         Left            =   720
         RightToLeft     =   -1  'True
         TabIndex        =   20
         Top             =   945
         Width           =   810
      End
      Begin VB.Label Label4 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "������"
         Height          =   195
         Left            =   2115
         RightToLeft     =   -1  'True
         TabIndex        =   19
         Top             =   945
         Width           =   405
      End
      Begin VB.Label Label3 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "��� ������"
         Height          =   195
         Left            =   2790
         RightToLeft     =   -1  'True
         TabIndex        =   18
         Top             =   945
         Width           =   750
      End
      Begin VB.Label Label2 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "�������"
         Height          =   195
         Left            =   3420
         RightToLeft     =   -1  'True
         TabIndex        =   17
         Top             =   585
         Width           =   480
      End
      Begin VB.Label Label1 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "�����"
         Height          =   195
         Left            =   3510
         RightToLeft     =   -1  'True
         TabIndex        =   16
         Top             =   225
         Width           =   345
      End
   End
   Begin VB.Frame Frame3 
      Caption         =   "����� �������"
      Height          =   3300
      Left            =   1350
      RightToLeft     =   -1  'True
      TabIndex        =   29
      Top             =   540
      Width           =   4020
      Begin VB.TextBox Text16 
         Alignment       =   1  'Right Justify
         Appearance      =   0  'Flat
         DataField       =   "SName"
         DataSource      =   "Data1"
         Height          =   330
         Left            =   90
         Locked          =   -1  'True
         RightToLeft     =   -1  'True
         TabIndex        =   41
         Text            =   "Text1"
         Top             =   270
         Width           =   3300
      End
      Begin VB.TextBox Text15 
         Alignment       =   1  'Right Justify
         Appearance      =   0  'Flat
         DataField       =   "ADDR"
         DataSource      =   "Data1"
         Height          =   330
         Left            =   90
         Locked          =   -1  'True
         RightToLeft     =   -1  'True
         TabIndex        =   40
         Text            =   "Text1"
         Top             =   630
         Width           =   3300
      End
      Begin VB.TextBox Text14 
         Alignment       =   1  'Right Justify
         Appearance      =   0  'Flat
         DataField       =   "Id"
         DataSource      =   "Data1"
         Height          =   330
         Left            =   2565
         Locked          =   -1  'True
         RightToLeft     =   -1  'True
         TabIndex        =   39
         Text            =   "Text1"
         Top             =   1305
         Width           =   1005
      End
      Begin VB.TextBox Text13 
         Alignment       =   1  'Right Justify
         Appearance      =   0  'Flat
         DataField       =   "Gr"
         DataSource      =   "Data1"
         Height          =   330
         Left            =   1530
         Locked          =   -1  'True
         RightToLeft     =   -1  'True
         TabIndex        =   38
         Text            =   "Text1"
         Top             =   1305
         Width           =   1005
      End
      Begin VB.TextBox Text12 
         Alignment       =   1  'Right Justify
         Appearance      =   0  'Flat
         DataField       =   "Ph"
         DataSource      =   "Data1"
         Height          =   330
         Left            =   495
         Locked          =   -1  'True
         RightToLeft     =   -1  'True
         TabIndex        =   37
         Text            =   "Text1"
         Top             =   1305
         Width           =   1005
      End
      Begin VB.TextBox Text11 
         Alignment       =   1  'Right Justify
         Appearance      =   0  'Flat
         DataField       =   "X"
         DataSource      =   "Data1"
         Height          =   330
         Left            =   2565
         RightToLeft     =   -1  'True
         TabIndex        =   36
         Text            =   "Text1"
         Top             =   1935
         Width           =   1005
      End
      Begin VB.TextBox Text10 
         Alignment       =   1  'Right Justify
         Appearance      =   0  'Flat
         DataField       =   "Y"
         DataSource      =   "Data1"
         Height          =   330
         Left            =   1530
         RightToLeft     =   -1  'True
         TabIndex        =   35
         Text            =   "Text1"
         Top             =   1935
         Width           =   1005
      End
      Begin VB.TextBox Text9 
         Alignment       =   1  'Right Justify
         Appearance      =   0  'Flat
         DataField       =   "Z"
         DataSource      =   "Data1"
         Height          =   330
         Left            =   495
         RightToLeft     =   -1  'True
         TabIndex        =   34
         Text            =   "Text1"
         Top             =   1935
         Width           =   1005
      End
      Begin VB.CommandButton Command16 
         Caption         =   "�������"
         Height          =   375
         Left            =   2610
         RightToLeft     =   -1  'True
         TabIndex        =   33
         Top             =   2340
         Width           =   1140
      End
      Begin VB.CommandButton Command15 
         Caption         =   "�����"
         Height          =   375
         Left            =   1395
         RightToLeft     =   -1  'True
         TabIndex        =   32
         Top             =   2340
         Width           =   1140
      End
      Begin VB.CommandButton Command13 
         Caption         =   "���"
         Height          =   375
         Left            =   180
         RightToLeft     =   -1  'True
         TabIndex        =   31
         Top             =   2340
         Width           =   1140
      End
      Begin VB.CommandButton Command12 
         Caption         =   "����"
         Height          =   375
         Left            =   1350
         RightToLeft     =   -1  'True
         TabIndex        =   30
         Top             =   2835
         Width           =   1140
      End
      Begin VB.Label Label16 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "�����"
         Height          =   195
         Left            =   3510
         RightToLeft     =   -1  'True
         TabIndex        =   49
         Top             =   315
         Width           =   345
      End
      Begin VB.Label Label15 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "�������"
         Height          =   195
         Left            =   3420
         RightToLeft     =   -1  'True
         TabIndex        =   48
         Top             =   675
         Width           =   480
      End
      Begin VB.Label Label14 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "��� ������"
         Height          =   195
         Left            =   2790
         RightToLeft     =   -1  'True
         TabIndex        =   47
         Top             =   1035
         Width           =   750
      End
      Begin VB.Label Label13 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "������"
         Height          =   195
         Left            =   2115
         RightToLeft     =   -1  'True
         TabIndex        =   46
         Top             =   1035
         Width           =   405
      End
      Begin VB.Label Label12 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "��� ��������"
         Height          =   195
         Left            =   720
         RightToLeft     =   -1  'True
         TabIndex        =   45
         Top             =   1035
         Width           =   810
      End
      Begin VB.Label Label11 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "������ ������"
         Height          =   195
         Left            =   2700
         RightToLeft     =   -1  'True
         TabIndex        =   44
         Top             =   1710
         Width           =   855
      End
      Begin VB.Label Label10 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "������ �������"
         Height          =   195
         Left            =   1710
         RightToLeft     =   -1  'True
         TabIndex        =   43
         Top             =   1710
         Width           =   840
      End
      Begin VB.Label Label9 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "������ �������"
         Height          =   195
         Left            =   675
         RightToLeft     =   -1  'True
         TabIndex        =   42
         Top             =   1710
         Width           =   825
      End
   End
   Begin VB.Frame Frame1 
      Caption         =   "������ ��������"
      Height          =   5145
      Left            =   2295
      RightToLeft     =   -1  'True
      TabIndex        =   0
      Top             =   90
      Width           =   1905
      Begin VB.CommandButton Command17 
         Caption         =   "�������� �� ������ 3"
         Height          =   555
         Left            =   135
         RightToLeft     =   -1  'True
         TabIndex        =   53
         Top             =   2610
         Width           =   1590
      End
      Begin VB.CommandButton Command14 
         Caption         =   "�������� �� ������ 2"
         Height          =   555
         Left            =   135
         RightToLeft     =   -1  'True
         TabIndex        =   52
         Top             =   2025
         Width           =   1590
      End
      Begin VB.CommandButton Command6 
         Caption         =   "����"
         Height          =   555
         Left            =   135
         RightToLeft     =   -1  'True
         TabIndex        =   6
         Top             =   4455
         Width           =   1590
      End
      Begin VB.CommandButton Command4 
         Caption         =   "������ �� ������� "
         Height          =   555
         Left            =   135
         RightToLeft     =   -1  'True
         TabIndex        =   4
         Top             =   3240
         Width           =   1590
      End
      Begin VB.CommandButton Command3 
         Caption         =   "�������� �� ������ 1"
         Height          =   555
         Left            =   135
         RightToLeft     =   -1  'True
         TabIndex        =   3
         Top             =   1440
         Width           =   1590
      End
      Begin VB.CommandButton Command2 
         Caption         =   "����� �������"
         Height          =   555
         Left            =   135
         RightToLeft     =   -1  'True
         TabIndex        =   2
         Top             =   855
         Width           =   1590
      End
      Begin VB.CommandButton Command1 
         Caption         =   "������ ������"
         Height          =   555
         Left            =   135
         RightToLeft     =   -1  'True
         TabIndex        =   1
         Top             =   225
         Width           =   1590
      End
      Begin VB.CommandButton Command5 
         Caption         =   "����� ��� �����"
         Height          =   555
         Left            =   135
         RightToLeft     =   -1  'True
         TabIndex        =   5
         Top             =   3825
         Width           =   1590
      End
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub Command1_Click()
Frame2.Visible = True
Frame1.Visible = False
Frame3.Visible = False
Frame4.Visible = False
End Sub

Private Sub Command10_Click()
Dim a As String
a = InputBox("���� ��� ������")
Data1.Recordset.FindFirst "id = '" + a + "'"
If Data1.Recordset.NoMatch Then
MsgBox ("Not Found")
End If

End Sub

Private Sub Command11_Click()
Frame2.Visible = False
Frame1.Visible = True

Data2.RecordSource = "select count(id) from students"
Data2.Refresh
Dim a As Integer
a = Data2.Recordset(0)
If a = 0 Then
Command9.Enabled = False
Command2.Enabled = False
Command3.Enabled = False
Command4.Enabled = False
Command5.Enabled = False
Command13.Enabled = False
Command14.Enabled = False
Command17.Enabled = False
End If
If a > 0 Then
Command9.Enabled = True
Command2.Enabled = True
Command3.Enabled = True
Command4.Enabled = True
Command5.Enabled = True
Command13.Enabled = True
Command14.Enabled = True
Command17.Enabled = True
End If
End Sub

Private Sub Command14_Click()
Label17.Visible = False
Label18.Visible = False
Text17.Visible = False
Text18.Visible = False
Command19.Visible = False

Frame4.Visible = True
Frame1.Visible = False
Frame3.Visible = False
Frame2.Visible = False
Frame4.Caption = "�������� �� ������ 2"
Data2.RecordSource = "select Sname as �����,id as ������,y as ������� from students where y >= 50"
Data2.Refresh
End Sub

Private Sub Command12_Click()
Frame3.Visible = False
Frame1.Visible = True

Data2.RecordSource = "select count(id) from students"
Data2.Refresh
Dim a As Integer
a = Data2.Recordset(0)
If a = 0 Then
Command9.Enabled = False
Command2.Enabled = False
Command3.Enabled = False
Command4.Enabled = False
Command5.Enabled = False
Command13.Enabled = False
Command14.Enabled = False
Command17.Enabled = False
End If

End Sub

Private Sub Command13_Click()
Data1.Recordset.Delete
Data1.Refresh

Data2.RecordSource = "select count(id) from students"
Data2.Refresh
Dim a As Integer
a = Data2.Recordset(0)
If a = 0 Then
Command13.Enabled = False
End If


End Sub

Private Sub Command15_Click()
Data1.Recordset.Edit
Data1.Recordset.Update

End Sub

Private Sub Command16_Click()
Dim a As String
a = InputBox("���� ��� ������")
Data1.Recordset.FindFirst "id = '" + a + "'"
If Data1.Recordset.NoMatch Then
MsgBox ("Not Found")
End If
End Sub

Private Sub Command17_Click()
Label17.Visible = False
Label18.Visible = False
Text17.Visible = False
Text18.Visible = False
Command19.Visible = False

Frame4.Visible = True
Frame1.Visible = False
Frame3.Visible = False
Frame2.Visible = False
Frame4.Caption = "�������� �� ������ 3"
Data2.RecordSource = "select Sname as �����,id as ������,z as ������� from students where z >= 50"
Data2.Refresh
End Sub

Private Sub Command18_Click()
Frame4.Visible = False
Frame1.Visible = True
Data2.RecordSource = "select id from students where id = '******'"
Data2.Refresh
End Sub

Private Sub Command19_Click()
Dim firstnumber, secondnumber, sel As String
firstnumber = Text18.Text
secondnumber = Text17.Text
sel = "Select * From Students Where X + Y + Z >= " + firstnumber + " And X + Y + Z <= " + secondnumber + ""
Data2.RecordSource = sel
Data2.Refresh
End Sub

Private Sub Command2_Click()
Frame3.Visible = True
Frame1.Visible = False
Frame2.Visible = False
Frame4.Visible = False
End Sub

Private Sub Command3_Click()
Label17.Visible = False
Label18.Visible = False
Text17.Visible = False
Text18.Visible = False
Command19.Visible = False

Frame4.Visible = True
Frame1.Visible = False
Frame3.Visible = False
Frame2.Visible = False
Frame4.Caption = "�������� �� ������ 1"
Data2.RecordSource = "select Sname as �����,id as ������,x as ������ from students where x >= 50"
Data2.Refresh
End Sub

Private Sub Command4_Click()
Label17.Visible = False
Label18.Visible = False
Text17.Visible = False
Text18.Visible = False
Command19.Visible = False

Frame4.Visible = True
Frame1.Visible = False
Frame3.Visible = False
Frame2.Visible = False
Frame4.Caption = "�������� �� ������� �����"
Dim a As String
a = "select Sname as �����,id as ������,x as ������,y as �������,z as ������� from students where x + y + z < 150"
Data2.RecordSource = a
Data2.Refresh

End Sub

Private Sub Command5_Click()
Frame4.Visible = True
Frame1.Visible = False
Frame3.Visible = False
Frame2.Visible = False
Frame4.Caption = "������ ��� ������ �������� ��� ����� ��� �����"

Label17.Visible = True
Label18.Visible = True
Text17.Visible = True
Text18.Visible = True
Command19.Visible = True

End Sub

Private Sub Command6_Click()
End
End Sub

Private Sub Command7_Click()
Data1.Recordset.AddNew
Command7.Enabled = False

End Sub

Private Sub Command8_Click()
Data1.Recordset.Update
Command7.Enabled = True
Command9.Enabled = True
Command13.Enabled = True

End Sub

Private Sub Command9_Click()
Data1.Recordset.Delete
Data1.Refresh

Data2.RecordSource = "select count(id) from students"
Data2.Refresh
Dim a As Integer
a = Data2.Recordset(0)
If a = 0 Then
Command9.Enabled = False
End If

End Sub

Private Sub Form_Load()
Frame1.Visible = True
Frame2.Visible = False
Frame3.Visible = False
Frame4.Visible = False

Data2.RecordSource = "select count(id) from students"
Data2.Refresh
Dim a As Integer
a = Data2.Recordset(0)
If a = 0 Then
Command2.Enabled = False
Command3.Enabled = False
Command4.Enabled = False
Command5.Enabled = False
Command9.Enabled = False
Command13.Enabled = False
Command14.Enabled = False
Command17.Enabled = False
End If
End Sub

