VERSION 5.00
Object = "{BDC217C8-ED16-11CD-956C-0000C04E4C0A}#1.1#0"; "TABCTL32.OCX"
Object = "{FAEEE763-117E-101B-8933-08002B2F4F5A}#1.1#0"; "DBLIST32.OCX"
Object = "{86CF1D34-0C5F-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCT2.OCX"
Begin VB.Form Form1 
   Caption         =   "������ �������"
   ClientHeight    =   5970
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   7155
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   RightToLeft     =   -1  'True
   ScaleHeight     =   5970
   ScaleWidth      =   7155
   StartUpPosition =   2  'CenterScreen
   Begin TabDlg.SSTab SSTab1 
      Height          =   5460
      Left            =   135
      TabIndex        =   0
      Top             =   45
      Width           =   6840
      _ExtentX        =   12065
      _ExtentY        =   9631
      _Version        =   393216
      Tabs            =   4
      Tab             =   2
      TabHeight       =   520
      TabCaption(0)   =   "������ ��������"
      TabPicture(0)   =   "Form1.frx":0000
      Tab(0).ControlEnabled=   0   'False
      Tab(0).Control(0)=   "Frame1"
      Tab(0).ControlCount=   1
      TabCaption(1)   =   "������ �������"
      TabPicture(1)   =   "Form1.frx":001C
      Tab(1).ControlEnabled=   0   'False
      Tab(1).Control(0)=   "Frame2"
      Tab(1).Control(0).Enabled=   0   'False
      Tab(1).ControlCount=   1
      TabCaption(2)   =   "���� ���������"
      TabPicture(2)   =   "Form1.frx":0038
      Tab(2).ControlEnabled=   -1  'True
      Tab(2).Control(0)=   "Frame3"
      Tab(2).Control(0).Enabled=   0   'False
      Tab(2).ControlCount=   1
      TabCaption(3)   =   "������� ��������"
      TabPicture(3)   =   "Form1.frx":0054
      Tab(3).ControlEnabled=   0   'False
      Tab(3).Control(0)=   "Frame4"
      Tab(3).Control(0).Enabled=   0   'False
      Tab(3).ControlCount=   1
      Begin VB.Frame Frame1 
         Caption         =   "������ ��������"
         Height          =   4605
         Left            =   -73920
         RightToLeft     =   -1  'True
         TabIndex        =   61
         Top             =   675
         Width           =   4380
         Begin VB.Data Data1 
            Caption         =   "Vendors"
            Connect         =   "Access 2000;"
            DatabaseName    =   "Store.mdb"
            DefaultCursorType=   0  'DefaultCursor
            DefaultType     =   2  'UseODBC
            Exclusive       =   0   'False
            Height          =   345
            Left            =   2340
            Options         =   0
            ReadOnly        =   0   'False
            RecordsetType   =   1  'Dynaset
            RecordSource    =   "Vendors"
            RightToLeft     =   -1  'True
            Top             =   4140
            Width           =   1950
         End
         Begin VB.TextBox Text1 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "V1"
            DataSource      =   "Data1"
            Height          =   375
            Left            =   135
            RightToLeft     =   -1  'True
            TabIndex        =   1
            Text            =   "Text1"
            Top             =   225
            Width           =   3120
         End
         Begin VB.TextBox Text2 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "V2"
            DataSource      =   "Data1"
            Height          =   375
            Left            =   135
            RightToLeft     =   -1  'True
            TabIndex        =   2
            Text            =   "Text1"
            Top             =   630
            Width           =   3120
         End
         Begin VB.TextBox Text3 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "V0"
            DataSource      =   "Data1"
            Height          =   375
            Left            =   135
            RightToLeft     =   -1  'True
            TabIndex        =   5
            Text            =   "Text1"
            Top             =   1800
            Width           =   3030
         End
         Begin VB.TextBox Text4 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "V3"
            DataSource      =   "Data1"
            Height          =   375
            Left            =   2385
            RightToLeft     =   -1  'True
            TabIndex        =   3
            Text            =   "Text1"
            Top             =   1350
            Width           =   1860
         End
         Begin VB.TextBox Text5 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "V5"
            DataSource      =   "Data1"
            Height          =   375
            Left            =   135
            RightToLeft     =   -1  'True
            TabIndex        =   4
            Text            =   "Text1"
            Top             =   1350
            Width           =   2220
         End
         Begin VB.TextBox Text6 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "V7"
            DataSource      =   "Data1"
            Height          =   375
            Left            =   3060
            RightToLeft     =   -1  'True
            TabIndex        =   6
            Text            =   "Text1"
            Top             =   2385
            Width           =   1185
         End
         Begin VB.TextBox Text7 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "V6"
            DataSource      =   "Data1"
            Height          =   375
            Left            =   1800
            RightToLeft     =   -1  'True
            TabIndex        =   7
            Text            =   "Text1"
            Top             =   2385
            Width           =   1185
         End
         Begin VB.TextBox Text8 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "V4"
            DataSource      =   "Data1"
            Height          =   375
            Left            =   135
            RightToLeft     =   -1  'True
            TabIndex        =   8
            Text            =   "Text1"
            Top             =   2385
            Width           =   1635
         End
         Begin VB.TextBox Text9 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "V8"
            DataSource      =   "Data1"
            Height          =   645
            Left            =   135
            MultiLine       =   -1  'True
            RightToLeft     =   -1  'True
            ScrollBars      =   2  'Vertical
            TabIndex        =   9
            Text            =   "Form1.frx":0070
            Top             =   2925
            Width           =   4110
         End
         Begin VB.CommandButton Command1 
            Caption         =   "����"
            Height          =   420
            Left            =   2970
            RightToLeft     =   -1  'True
            TabIndex        =   10
            Top             =   3645
            Width           =   1230
         End
         Begin VB.CommandButton Command2 
            Caption         =   "���"
            Height          =   420
            Left            =   1665
            RightToLeft     =   -1  'True
            TabIndex        =   11
            Top             =   3645
            Width           =   1230
         End
         Begin VB.CommandButton Command3 
            Caption         =   "���"
            Height          =   420
            Left            =   315
            RightToLeft     =   -1  'True
            TabIndex        =   12
            Top             =   3645
            Width           =   1230
         End
         Begin MSDBCtls.DBCombo DBCombo1 
            Bindings        =   "Form1.frx":0076
            Height          =   315
            Left            =   180
            TabIndex        =   13
            Top             =   4140
            Width           =   1950
            _ExtentX        =   3440
            _ExtentY        =   556
            _Version        =   393216
            ListField       =   "V1"
            Text            =   "������� ����"
            RightToLeft     =   -1  'True
         End
         Begin VB.Label Label9 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "�������"
            Height          =   195
            Left            =   3645
            RightToLeft     =   -1  'True
            TabIndex        =   72
            Top             =   2745
            Width           =   570
         End
         Begin VB.Label Label8 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "������"
            Height          =   195
            Left            =   1395
            RightToLeft     =   -1  'True
            TabIndex        =   71
            Top             =   2205
            Width           =   360
         End
         Begin VB.Label Label7 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "����� �������"
            Height          =   195
            Left            =   2025
            RightToLeft     =   -1  'True
            TabIndex        =   70
            Top             =   2160
            Width           =   1020
         End
         Begin VB.Label Label6 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "������� ��������"
            Height          =   195
            Left            =   3195
            RightToLeft     =   -1  'True
            TabIndex        =   69
            Top             =   2160
            Width           =   1050
         End
         Begin VB.Label Label5 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "��� �������"
            Height          =   195
            Left            =   3330
            RightToLeft     =   -1  'True
            TabIndex        =   68
            Top             =   1845
            Width           =   780
         End
         Begin VB.Label Label4 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "��� ��������"
            Height          =   195
            Left            =   1440
            RightToLeft     =   -1  'True
            TabIndex        =   67
            Top             =   1080
            Width           =   825
         End
         Begin VB.Label Label3 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "��� ��������"
            Height          =   195
            Left            =   3375
            RightToLeft     =   -1  'True
            TabIndex        =   66
            Top             =   1080
            Width           =   810
         End
         Begin VB.Label Label2 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "�������"
            Height          =   195
            Left            =   3645
            RightToLeft     =   -1  'True
            TabIndex        =   65
            Top             =   675
            Width           =   480
         End
         Begin VB.Label Label1 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "��� ������"
            Height          =   195
            Left            =   3510
            RightToLeft     =   -1  'True
            TabIndex        =   64
            Top             =   225
            Width           =   705
         End
      End
      Begin VB.Frame Frame4 
         Caption         =   "������� ��������"
         Height          =   3615
         Left            =   -73290
         RightToLeft     =   -1  'True
         TabIndex        =   51
         Top             =   765
         Width           =   3255
         Begin VB.CommandButton Command4 
            Caption         =   "���"
            Height          =   465
            Left            =   225
            RightToLeft     =   -1  'True
            TabIndex        =   73
            Top             =   2610
            Width           =   825
         End
         Begin VB.Data Data4 
            Caption         =   "Vout"
            Connect         =   "Access 2000;"
            DatabaseName    =   "Store.mdb"
            DefaultCursorType=   0  'DefaultCursor
            DefaultType     =   2  'UseODBC
            Exclusive       =   0   'False
            Height          =   345
            Left            =   225
            Options         =   0
            ReadOnly        =   0   'False
            RecordsetType   =   1  'Dynaset
            RecordSource    =   "Vout"
            RightToLeft     =   -1  'True
            Top             =   3150
            Width           =   2805
         End
         Begin MSComCtl2.DTPicker DTPicker2 
            DataField       =   "N2"
            DataSource      =   "Data4"
            Height          =   375
            Left            =   90
            TabIndex        =   63
            Top             =   585
            Width           =   2220
            _ExtentX        =   3916
            _ExtentY        =   661
            _Version        =   393216
            Format          =   52035585
            CurrentDate     =   41557
         End
         Begin VB.CommandButton Command14 
            Caption         =   "���"
            Height          =   465
            Left            =   1215
            RightToLeft     =   -1  'True
            TabIndex        =   60
            Top             =   2610
            Width           =   960
         End
         Begin VB.CommandButton Command13 
            Caption         =   "����"
            Height          =   465
            Left            =   2340
            RightToLeft     =   -1  'True
            TabIndex        =   59
            Top             =   2610
            Width           =   825
         End
         Begin VB.TextBox Text23 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "N3"
            DataSource      =   "Data4"
            Height          =   870
            Left            =   135
            MultiLine       =   -1  'True
            RightToLeft     =   -1  'True
            ScrollBars      =   2  'Vertical
            TabIndex        =   58
            Text            =   "Form1.frx":008A
            Top             =   1665
            Width           =   2895
         End
         Begin VB.TextBox Text21 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "N1"
            DataSource      =   "Data4"
            Height          =   330
            Left            =   90
            RightToLeft     =   -1  'True
            TabIndex        =   57
            Text            =   "Text21"
            Top             =   1035
            Width           =   2220
         End
         Begin MSDBCtls.DBCombo DBCombo6 
            Bindings        =   "Form1.frx":0091
            DataField       =   "N0"
            DataSource      =   "Data4"
            Height          =   315
            Left            =   45
            TabIndex        =   56
            Top             =   225
            Width           =   2265
            _ExtentX        =   3995
            _ExtentY        =   556
            _Version        =   393216
            ListField       =   "V1"
            Text            =   "DBCombo6"
            RightToLeft     =   -1  'True
         End
         Begin VB.Label Label27 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "������"
            Height          =   195
            Left            =   2655
            RightToLeft     =   -1  'True
            TabIndex        =   55
            Top             =   1395
            Width           =   375
         End
         Begin VB.Label Label26 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "�������"
            Height          =   195
            Left            =   2565
            RightToLeft     =   -1  'True
            TabIndex        =   54
            Top             =   675
            Width           =   465
         End
         Begin VB.Label Label25 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "������"
            Height          =   195
            Left            =   2655
            RightToLeft     =   -1  'True
            TabIndex        =   53
            Top             =   1080
            Width           =   375
         End
         Begin VB.Label Label24 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "��� ������"
            Height          =   195
            Left            =   2430
            RightToLeft     =   -1  'True
            TabIndex        =   52
            Top             =   225
            Width           =   720
         End
      End
      Begin VB.Frame Frame3 
         Caption         =   "���� ���������"
         Height          =   4200
         Left            =   90
         RightToLeft     =   -1  'True
         TabIndex        =   29
         Top             =   720
         Width           =   6540
         Begin VB.Data Data3 
            Caption         =   "MoveIn"
            Connect         =   "Access 2000;"
            DatabaseName    =   "Store.mdb"
            DefaultCursorType=   0  'DefaultCursor
            DefaultType     =   2  'UseODBC
            Exclusive       =   0   'False
            Height          =   345
            Left            =   1170
            Options         =   0
            ReadOnly        =   0   'False
            RecordsetType   =   1  'Dynaset
            RecordSource    =   "MoveIn"
            RightToLeft     =   -1  'True
            Top             =   3735
            Width           =   3885
         End
         Begin MSComCtl2.DTPicker DTPicker1 
            DataField       =   "M3"
            DataSource      =   "Data3"
            Height          =   330
            Left            =   180
            TabIndex        =   62
            Top             =   720
            Width           =   2220
            _ExtentX        =   3916
            _ExtentY        =   582
            _Version        =   393216
            Format          =   52035585
            CurrentDate     =   41557
         End
         Begin VB.CommandButton Command12 
            Caption         =   "�������"
            Height          =   420
            Left            =   630
            RightToLeft     =   -1  'True
            TabIndex        =   50
            Top             =   3240
            Width           =   1050
         End
         Begin VB.CommandButton Command11 
            Caption         =   "���"
            Height          =   420
            Left            =   1800
            RightToLeft     =   -1  'True
            TabIndex        =   49
            Top             =   3240
            Width           =   1050
         End
         Begin VB.CommandButton Command10 
            Caption         =   "���"
            Height          =   420
            Left            =   3060
            RightToLeft     =   -1  'True
            TabIndex        =   48
            Top             =   3240
            Width           =   1050
         End
         Begin VB.CommandButton Command9 
            Caption         =   "����"
            Height          =   420
            Left            =   4275
            RightToLeft     =   -1  'True
            TabIndex        =   47
            Top             =   3240
            Width           =   1050
         End
         Begin VB.TextBox Text20 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "M8"
            DataSource      =   "Data3"
            Height          =   915
            Left            =   180
            RightToLeft     =   -1  'True
            TabIndex        =   46
            Text            =   "Text14"
            Top             =   2250
            Width           =   5685
         End
         Begin VB.TextBox Text19 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "M7"
            DataSource      =   "Data3"
            Height          =   330
            Left            =   180
            RightToLeft     =   -1  'True
            TabIndex        =   45
            Text            =   "Text14"
            Top             =   1710
            Width           =   2175
         End
         Begin VB.TextBox Text18 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "M6"
            DataSource      =   "Data3"
            Height          =   330
            Left            =   3510
            RightToLeft     =   -1  'True
            TabIndex        =   44
            Text            =   "Text14"
            Top             =   1710
            Width           =   1950
         End
         Begin VB.TextBox Text17 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "M5"
            DataSource      =   "Data3"
            Height          =   330
            Left            =   180
            RightToLeft     =   -1  'True
            TabIndex        =   43
            Text            =   "Text14"
            Top             =   1215
            Width           =   2175
         End
         Begin VB.TextBox Text16 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "M4"
            DataSource      =   "Data3"
            Height          =   330
            Left            =   3510
            RightToLeft     =   -1  'True
            TabIndex        =   42
            Text            =   "Text14"
            Top             =   1170
            Width           =   1950
         End
         Begin VB.TextBox Text14 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "M2"
            DataSource      =   "Data3"
            Height          =   330
            Left            =   3510
            RightToLeft     =   -1  'True
            TabIndex        =   41
            Text            =   "Text14"
            Top             =   675
            Width           =   1950
         End
         Begin MSDBCtls.DBCombo DBCombo5 
            Bindings        =   "Form1.frx":00A5
            DataField       =   "M1"
            DataSource      =   "Data3"
            Height          =   315
            Left            =   180
            TabIndex        =   40
            Top             =   270
            Width           =   2220
            _ExtentX        =   3916
            _ExtentY        =   556
            _Version        =   393216
            ListField       =   "V1"
            Text            =   "DBCombo5"
            RightToLeft     =   -1  'True
         End
         Begin MSDBCtls.DBCombo DBCombo4 
            Bindings        =   "Form1.frx":00B9
            DataField       =   "M0"
            DataSource      =   "Data3"
            Height          =   315
            Left            =   3465
            TabIndex        =   39
            Top             =   270
            Width           =   1995
            _ExtentX        =   3519
            _ExtentY        =   556
            _Version        =   393216
            ListField       =   "F0"
            Text            =   "DBCombo4"
            RightToLeft     =   -1  'True
         End
         Begin VB.Label Label23 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "������"
            Height          =   195
            Left            =   5985
            RightToLeft     =   -1  'True
            TabIndex        =   38
            Top             =   2250
            Width           =   375
         End
         Begin VB.Label Label22 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "��� ��� �������"
            Height          =   195
            Left            =   2430
            RightToLeft     =   -1  'True
            TabIndex        =   37
            Top             =   1755
            Width           =   1020
         End
         Begin VB.Label Label21 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "������"
            Height          =   195
            Left            =   6030
            RightToLeft     =   -1  'True
            TabIndex        =   36
            Top             =   1845
            Width           =   375
         End
         Begin VB.Label Label20 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "��� ������"
            Height          =   195
            Left            =   2625
            RightToLeft     =   -1  'True
            TabIndex        =   35
            Top             =   1215
            Width           =   780
         End
         Begin VB.Label Label19 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "������"
            Height          =   195
            Left            =   6000
            RightToLeft     =   -1  'True
            TabIndex        =   34
            Top             =   1305
            Width           =   405
         End
         Begin VB.Label Label18 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "�������"
            Height          =   195
            Left            =   2940
            RightToLeft     =   -1  'True
            TabIndex        =   33
            Top             =   720
            Width           =   465
         End
         Begin VB.Label Label17 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "��� �������"
            Height          =   195
            Left            =   5610
            RightToLeft     =   -1  'True
            TabIndex        =   32
            Top             =   765
            Width           =   795
         End
         Begin VB.Label Label16 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "��� ������"
            Height          =   195
            Left            =   2685
            RightToLeft     =   -1  'True
            TabIndex        =   31
            Top             =   315
            Width           =   720
         End
         Begin VB.Label Label15 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "��� �����"
            Height          =   195
            Left            =   5670
            RightToLeft     =   -1  'True
            TabIndex        =   30
            Top             =   315
            Width           =   735
         End
      End
      Begin VB.Frame Frame2 
         Caption         =   "������ �������"
         Height          =   4425
         Left            =   -73605
         RightToLeft     =   -1  'True
         TabIndex        =   14
         Top             =   720
         Width           =   3615
         Begin VB.Data Data2 
            Caption         =   "Items"
            Connect         =   "Access 2000;"
            DatabaseName    =   "Store.mdb"
            DefaultCursorType=   0  'DefaultCursor
            DefaultType     =   2  'UseODBC
            Exclusive       =   0   'False
            Height          =   345
            Left            =   90
            Options         =   0
            ReadOnly        =   0   'False
            RecordsetType   =   1  'Dynaset
            RecordSource    =   "Items"
            RightToLeft     =   -1  'True
            Top             =   4005
            Width           =   3390
         End
         Begin MSDBCtls.DBCombo DBCombo3 
            Bindings        =   "Form1.frx":00CD
            Height          =   315
            Left            =   135
            TabIndex        =   28
            Top             =   3600
            Width           =   3300
            _ExtentX        =   5821
            _ExtentY        =   556
            _Version        =   393216
            ListField       =   "F0"
            Text            =   "������� ���"
            RightToLeft     =   -1  'True
         End
         Begin VB.CommandButton Command7 
            Caption         =   "���"
            Height          =   420
            Left            =   180
            RightToLeft     =   -1  'True
            TabIndex        =   27
            Top             =   3105
            Width           =   1095
         End
         Begin VB.CommandButton Command6 
            Caption         =   "���"
            Height          =   420
            Left            =   1395
            RightToLeft     =   -1  'True
            TabIndex        =   26
            Top             =   3105
            Width           =   1005
         End
         Begin VB.CommandButton Command5 
            Caption         =   "����"
            Height          =   420
            Left            =   2475
            RightToLeft     =   -1  'True
            TabIndex        =   25
            Top             =   3105
            Width           =   1050
         End
         Begin MSDBCtls.DBCombo DBCombo2 
            Bindings        =   "Form1.frx":00E1
            DataField       =   "F1"
            DataSource      =   "Data2"
            Height          =   315
            Left            =   90
            TabIndex        =   24
            Top             =   945
            Width           =   2490
            _ExtentX        =   4392
            _ExtentY        =   556
            _Version        =   393216
            ListField       =   "V1"
            Text            =   "DBCombo2"
            RightToLeft     =   -1  'True
         End
         Begin VB.TextBox Text13 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "F4"
            DataSource      =   "Data2"
            Height          =   1095
            Left            =   90
            MultiLine       =   -1  'True
            RightToLeft     =   -1  'True
            ScrollBars      =   2  'Vertical
            TabIndex        =   23
            Text            =   "Form1.frx":00F5
            Top             =   1980
            Width           =   3390
         End
         Begin VB.TextBox Text12 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "F3"
            DataSource      =   "Data2"
            Height          =   330
            Left            =   90
            RightToLeft     =   -1  'True
            TabIndex        =   22
            Text            =   "Text10"
            Top             =   1305
            Width           =   2490
         End
         Begin VB.TextBox Text11 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "F2"
            DataSource      =   "Data2"
            Height          =   330
            Left            =   90
            RightToLeft     =   -1  'True
            TabIndex        =   21
            Text            =   "Text10"
            Top             =   585
            Width           =   2490
         End
         Begin VB.TextBox Text10 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "F0"
            DataSource      =   "Data2"
            Height          =   330
            Left            =   90
            RightToLeft     =   -1  'True
            TabIndex        =   20
            Text            =   "Text10"
            Top             =   180
            Width           =   2490
         End
         Begin VB.Label Label14 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "���������"
            Height          =   195
            Left            =   2700
            RightToLeft     =   -1  'True
            TabIndex        =   19
            Top             =   1710
            Width           =   690
         End
         Begin VB.Label Label13 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "��� ������"
            Height          =   195
            Left            =   2745
            RightToLeft     =   -1  'True
            TabIndex        =   18
            Top             =   1350
            Width           =   660
         End
         Begin VB.Label Label12 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "��� ������"
            Height          =   195
            Left            =   2700
            RightToLeft     =   -1  'True
            TabIndex        =   17
            Top             =   990
            Width           =   720
         End
         Begin VB.Label Label11 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "�������"
            Height          =   195
            Left            =   2835
            RightToLeft     =   -1  'True
            TabIndex        =   16
            Top             =   630
            Width           =   480
         End
         Begin VB.Label Label10 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "��� �����"
            Height          =   195
            Left            =   2700
            RightToLeft     =   -1  'True
            TabIndex        =   15
            Top             =   225
            Width           =   735
         End
      End
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
Data1.Recordset.AddNew
Command1.Enabled = False
Command2.Enabled = True

End Sub

Private Sub Command10_Click()
Data3.Recordset.Update
Data3.Refresh

End Sub

Private Sub Command11_Click()
If Data3.Recordset.RecordCount = 0 Then
Command11.Enabled = False
Exit Sub
End If
Data3.Recordset.Delete
Data3.Refresh
End Sub

Private Sub Command12_Click()
Dim x As String
x = InputBox("���� ��� ��� �������")
Data3.Recordset.FindFirst ("M7 = '" + x + "'")
If Data3.Recordset.NoMatch Then
MsgBox ("�� ��� ������ ����")
End If
End Sub

Private Sub Command13_Click()
Data4.Recordset.AddNew
Command13.Enabled = False
Command14.Enabled = True


End Sub

Private Sub Command14_Click()
Data4.Recordset.Update
Data4.Refresh

Command13.Enabled = True

End Sub


Private Sub Command2_Click()
Data1.Recordset.Update
Data1.Refresh

Command1.Enabled = True
Command3.Enabled = True
Command2.Enabled = False
End Sub

Private Sub Command3_Click()
If Data1.Recordset.RecordCount = 0 Then
Command3.Enabled = False
Exit Sub
End If

Data1.Recordset.Delete
Data1.Refresh
End Sub

Private Sub Command4_Click()
If Data4.Recordset.RecordCount = 0 Then
Command4.Enabled = False
Exit Sub
End If

Data4.Recordset.Delete
Data4.Refresh

End Sub

Private Sub Command5_Click()
Data2.Recordset.AddNew
Command6.Enabled = True

End Sub

Private Sub Command6_Click()
Data2.Recordset.Update
Data2.Refresh

End Sub

Private Sub Command7_Click()
If Data2.Recordset.RecordCount = 0 Then
Command7.Enabled = False
Exit Sub
End If
Data2.Recordset.Delete
Data2.Refresh
End Sub

Private Sub Command9_Click()
Data3.Recordset.AddNew
Command10.Enabled = True

End Sub

Private Sub DBCombo1_Click(Area As Integer)
Data1.Recordset.FindFirst "V1 = '" + DBCombo1.Text + "'"

End Sub

Private Sub DBCombo3_Click(Area As Integer)
Data2.Recordset.FindFirst "F0 = '" + DBCombo3.Text + "'"
End Sub

Private Sub Form_Load()
Command2.Enabled = False
Command6.Enabled = False
Command10.Enabled = False
Command14.Enabled = False

End Sub

Private Sub Text1_KeyPress(KeyAscii As Integer)
If KeyAscii = 13 Then
Text2.SetFocus
End If

End Sub

Private Sub Text2_KeyPress(KeyAscii As Integer)
If KeyAscii = 13 Then
Text4.SetFocus
End If
End Sub

Private Sub Text3_KeyPress(KeyAscii As Integer)
If KeyAscii = 13 Then
Text6.SetFocus
End If
End Sub

Private Sub Text4_KeyPress(KeyAscii As Integer)
If KeyAscii = 13 Then
Text5.SetFocus
End If
End Sub

Private Sub Text5_KeyPress(KeyAscii As Integer)
If KeyAscii = 13 Then
Text3.SetFocus
End If
End Sub

Private Sub Text6_KeyPress(KeyAscii As Integer)
If KeyAscii = 13 Then
Text7.SetFocus
End If
End Sub

Private Sub Text7_KeyPress(KeyAscii As Integer)
If KeyAscii = 13 Then
Text8.SetFocus
End If
End Sub

Private Sub Text8_KeyPress(KeyAscii As Integer)
If KeyAscii = 13 Then
Text9.SetFocus
End If
End Sub

Private Sub Text9_Change()
If KeyAscii = 13 Then
Command2.SetFocus
End If
End Sub
