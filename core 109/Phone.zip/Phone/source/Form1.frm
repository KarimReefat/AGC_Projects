VERSION 5.00
Object = "{86CF1D34-0C5F-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCT2.OCX"
Object = "{74848F95-A02A-4286-AF0C-A3C755E4A5B3}#1.0#0"; "actskn43.ocx"
Begin VB.Form Form1 
   Caption         =   "���� ��������"
   ClientHeight    =   5985
   ClientLeft      =   5205
   ClientTop       =   270
   ClientWidth     =   4560
   Icon            =   "Form1.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   RightToLeft     =   -1  'True
   ScaleHeight     =   5985
   ScaleWidth      =   4560
   StartUpPosition =   2  'CenterScreen
   Begin VB.Data Data2 
      Caption         =   "Data2"
      Connect         =   "Access 2000;"
      DatabaseName    =   ""
      DefaultCursorType=   0  'DefaultCursor
      DefaultType     =   2  'UseODBC
      Exclusive       =   0   'False
      Height          =   345
      Left            =   45
      Options         =   0
      ReadOnly        =   0   'False
      RecordsetType   =   1  'Dynaset
      RecordSource    =   ""
      RightToLeft     =   -1  'True
      Top             =   3240
      Visible         =   0   'False
      Width           =   2310
   End
   Begin VB.CommandButton Command1 
      Caption         =   "����"
      Height          =   510
      Left            =   3015
      RightToLeft     =   -1  'True
      TabIndex        =   21
      Top             =   4275
      Width           =   1230
   End
   Begin ACTIVESKINLibCtl.SkinLabel SkinLabel1 
      Height          =   240
      Left            =   4050
      OleObjectBlob   =   "Form1.frx":1C64C
      TabIndex        =   13
      Top             =   0
      Width           =   465
   End
   Begin ACTIVESKINLibCtl.Skin Skin1 
      Left            =   0
      OleObjectBlob   =   "Form1.frx":1C6B4
      Top             =   4995
   End
   Begin VB.TextBox TxtId 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      DataField       =   "ID"
      DataSource      =   "Data1"
      Height          =   525
      Left            =   3285
      RightToLeft     =   -1  'True
      TabIndex        =   0
      Text            =   "Text1"
      Top             =   225
      Width           =   1245
   End
   Begin VB.TextBox TxtSname 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      DataField       =   "pname"
      DataSource      =   "Data1"
      Height          =   525
      Left            =   90
      RightToLeft     =   -1  'True
      TabIndex        =   1
      Text            =   "Text2"
      Top             =   225
      Width           =   3150
   End
   Begin VB.TextBox TxtAddress 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      DataField       =   "address"
      DataSource      =   "Data1"
      Height          =   525
      Left            =   45
      RightToLeft     =   -1  'True
      TabIndex        =   2
      Text            =   "Text3"
      Top             =   1035
      Width           =   4455
   End
   Begin VB.TextBox TxtTel 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      DataField       =   "tel"
      DataSource      =   "Data1"
      Height          =   525
      Left            =   2430
      RightToLeft     =   -1  'True
      TabIndex        =   3
      Text            =   "Text4"
      Top             =   1890
      Width           =   2070
   End
   Begin VB.TextBox TxtMob 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      DataField       =   "mob"
      DataSource      =   "Data1"
      Height          =   525
      Left            =   45
      RightToLeft     =   -1  'True
      TabIndex        =   4
      Text            =   "Text5"
      Top             =   1890
      Width           =   2340
   End
   Begin VB.TextBox TxtEmail 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      DataField       =   "email"
      DataSource      =   "Data1"
      Height          =   525
      Left            =   2430
      RightToLeft     =   -1  'True
      TabIndex        =   5
      Text            =   "Text6"
      Top             =   2700
      Width           =   2070
   End
   Begin VB.Data Data1 
      Caption         =   "Data1"
      Connect         =   "Access 2000;"
      DatabaseName    =   "Phone.mdb"
      DefaultCursorType=   0  'DefaultCursor
      DefaultType     =   2  'UseODBC
      Exclusive       =   0   'False
      Height          =   420
      Left            =   135
      Options         =   0
      ReadOnly        =   0   'False
      RecordsetType   =   1  'Dynaset
      RecordSource    =   "Phone"
      Top             =   5490
      Width           =   4425
   End
   Begin VB.CommandButton Command6 
      Caption         =   "����"
      Height          =   525
      Left            =   405
      TabIndex        =   12
      Top             =   4860
      Width           =   1245
   End
   Begin VB.CommandButton Command5 
      Caption         =   "�������"
      Height          =   525
      Left            =   3015
      TabIndex        =   11
      Top             =   4860
      Width           =   1245
   End
   Begin VB.CommandButton Command4 
      Caption         =   "���"
      Height          =   525
      Left            =   1710
      TabIndex        =   10
      Top             =   4860
      Width           =   1245
   End
   Begin VB.CommandButton Command3 
      Caption         =   "�����"
      Height          =   525
      Left            =   405
      TabIndex        =   9
      Top             =   4275
      Width           =   1245
   End
   Begin VB.CommandButton Btn 
      Caption         =   "���"
      Height          =   525
      Left            =   1710
      TabIndex        =   8
      Top             =   4275
      Width           =   1245
   End
   Begin VB.TextBox TxtPnote 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      DataField       =   "pnote"
      DataSource      =   "Data1"
      Height          =   600
      Left            =   45
      MultiLine       =   -1  'True
      RightToLeft     =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   7
      Text            =   "Form1.frx":4AD11
      Top             =   3600
      Width           =   4485
   End
   Begin MSComCtl2.DTPicker DTPPdate 
      DataField       =   "pdate"
      DataSource      =   "Data1"
      Height          =   525
      Left            =   45
      TabIndex        =   6
      Top             =   2700
      Width           =   2325
      _ExtentX        =   4101
      _ExtentY        =   926
      _Version        =   393216
      Format          =   33357825
      CurrentDate     =   41538
   End
   Begin ACTIVESKINLibCtl.SkinLabel SkinLabel2 
      Height          =   240
      Left            =   2790
      OleObjectBlob   =   "Form1.frx":4AD17
      TabIndex        =   14
      Top             =   0
      Width           =   465
   End
   Begin ACTIVESKINLibCtl.SkinLabel SkinLabel3 
      Height          =   240
      Left            =   4050
      OleObjectBlob   =   "Form1.frx":4AD7F
      TabIndex        =   15
      Top             =   765
      Width           =   465
   End
   Begin ACTIVESKINLibCtl.SkinLabel SkinLabel4 
      Height          =   240
      Left            =   3510
      OleObjectBlob   =   "Form1.frx":4ADEB
      TabIndex        =   16
      Top             =   1620
      Width           =   960
   End
   Begin ACTIVESKINLibCtl.SkinLabel SkinLabel5 
      Height          =   240
      Left            =   1800
      OleObjectBlob   =   "Form1.frx":4AE63
      TabIndex        =   17
      Top             =   1620
      Width           =   600
   End
   Begin ACTIVESKINLibCtl.SkinLabel SkinLabel6 
      Height          =   240
      Left            =   4050
      OleObjectBlob   =   "Form1.frx":4AED1
      TabIndex        =   18
      Top             =   2430
      Width           =   465
   End
   Begin ACTIVESKINLibCtl.SkinLabel SkinLabel7 
      Height          =   240
      Left            =   1350
      OleObjectBlob   =   "Form1.frx":4AF3D
      TabIndex        =   19
      Top             =   2430
      Width           =   1005
   End
   Begin ACTIVESKINLibCtl.SkinLabel SkinLabel8 
      Height          =   240
      Left            =   3870
      OleObjectBlob   =   "Form1.frx":4AFB5
      TabIndex        =   20
      Top             =   3285
      Width           =   600
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub Text5_Change()

End Sub

Private Sub Btn_Click()
Data1.Recordset.Update
Command1.Enabled = True
Btn.Enabled = False
Command3.Enabled = True
Command5.Enabled = True
End Sub

Private Sub Command1_Click()
Data1.Recordset.AddNew
Btn.Enabled = True
Command1.Enabled = False
Command4.Enabled = True


End Sub

Private Sub Command3_Click()
Data1.Recordset.Edit
Data1.Recordset.Update
End Sub

Private Sub Command4_Click()
Data1.Recordset.Delete
Data1.Refresh

Data2.RecordSource = "select count(id) from Phone"
Data2.Refresh
Dim a As Integer
a = Data2.Recordset(0)
If a = 0 Then
Command4.Enabled = False
Command3.Enabled = False
Command5.Enabled = False
End If

End Sub

Private Sub Command5_Click()
Dim x As String
x = InputBox("���� �����")
If x = "" Or IsNumeric(x) = 0 Then
Exit Sub
End If

Data1.Recordset.FindFirst ("Id = " + x + "")
If Data1.Recordset.NoMatch Then
MsgBox ("Not Found")
End If

End Sub

Private Sub Command6_Click()
End

End Sub

Private Sub DTPPdate_KeyPress(KeyAscii As Integer)
If KeyAscii = 13 Then
TxtPnote.SetFocus
End If
End Sub

Private Sub Form_Activate()
Data2.DatabaseName = "Phone.mdb"
Data2.RecordSource = "select count(id) from Phone"
Data2.Refresh
Dim a As Integer
a = Data2.Recordset(0)
If a = 0 Then
Command4.Enabled = False
Command3.Enabled = False
Command5.Enabled = Flase
End If
End Sub

Private Sub Form_Load()
Skin1.ApplySkin Me.hWnd
Btn.Enabled = False
End Sub

Private Sub TxtAddress_KeyPress(KeyAscii As Integer)
If KeyAscii = 13 Then
TxtTel.SetFocus
End If
End Sub

Private Sub TxtEmail_KeyPress(KeyAscii As Integer)
If KeyAscii = 13 Then
DTPPdate.SetFocus
End If
End Sub

Private Sub TxtId_KeyPress(KeyAscii As Integer)

If KeyAscii < 48 Or KeyAscii > 57 Then

    If KeyAscii = 13 Then
        TxtSname.SetFocus
    End If
    
    KeyAscii = 0
    
End If

End Sub

Private Sub TxtMob_Change()
If Not IsNumeric(TxtMob) Then
SendKeys "{backspace}"
End If
End Sub

Private Sub TxtMob_KeyPress(KeyAscii As Integer)
If KeyAscii = 13 Then
TxtEmail.SetFocus
End If
End Sub

Private Sub TxtPnote_KeyPress(KeyAscii As Integer)
If KeyAscii = 13 Then
Btn.Enabled = True
Btn.SetFocus
End If
End Sub

Private Sub TxtSname_KeyPress(KeyAscii As Integer)
If KeyAscii >= 48 And KeyAscii <= 57 Then
KeyAscii = 0
End If
If KeyAscii = 13 Then
TxtAddress.SetFocus
End If
End Sub

Private Sub TxtTel_Change()
If Not IsNumeric(TxtTel) Then
SendKeys "{backspace}"
End If
End Sub

Private Sub TxtTel_KeyPress(KeyAscii As Integer)
If KeyAscii = 13 Then
TxtMob.SetFocus
End If
End Sub
