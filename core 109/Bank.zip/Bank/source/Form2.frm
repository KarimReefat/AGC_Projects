VERSION 5.00
Object = "{00028C01-0000-0000-0000-000000000046}#1.0#0"; "DBGRID32.OCX"
Begin VB.Form Form2 
   Caption         =   "��� ������ �������"
   ClientHeight    =   5700
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   9255
   LinkTopic       =   "Form5"
   MaxButton       =   0   'False
   RightToLeft     =   -1  'True
   ScaleHeight     =   5700
   ScaleWidth      =   9255
   StartUpPosition =   2  'CenterScreen
   Begin MSDBGrid.DBGrid DBGrid2 
      Bindings        =   "Form2.frx":0000
      Height          =   1770
      Left            =   135
      OleObjectBlob   =   "Form2.frx":0014
      TabIndex        =   3
      Top             =   3285
      Width           =   8925
   End
   Begin VB.Data Data2 
      Caption         =   "Data2"
      Connect         =   "Access 2000;"
      DatabaseName    =   "Works.mdb"
      DefaultCursorType=   0  'DefaultCursor
      DefaultType     =   2  'UseODBC
      Exclusive       =   0   'False
      Height          =   390
      Left            =   135
      Options         =   0
      ReadOnly        =   0   'False
      RecordsetType   =   1  'Dynaset
      RecordSource    =   "Move"
      Top             =   5130
      Width           =   5280
   End
   Begin VB.Data Data1 
      Caption         =   "Data1"
      Connect         =   "Access 2000;"
      DatabaseName    =   "Works.mdb"
      DefaultCursorType=   0  'DefaultCursor
      DefaultType     =   2  'UseODBC
      Exclusive       =   0   'False
      Height          =   435
      Left            =   135
      Options         =   0
      ReadOnly        =   0   'False
      RecordsetType   =   1  'Dynaset
      RecordSource    =   "Customers"
      Top             =   2565
      Width           =   5325
   End
   Begin VB.CommandButton Command1 
      Caption         =   "��� ����"
      Height          =   510
      Left            =   5535
      TabIndex        =   1
      Top             =   2565
      Width           =   1230
   End
   Begin VB.CommandButton Command2 
      Caption         =   "���� ����"
      Height          =   510
      Left            =   5580
      TabIndex        =   0
      Top             =   5130
      Width           =   1230
   End
   Begin MSDBGrid.DBGrid DBGrid1 
      Bindings        =   "Form2.frx":09E7
      Height          =   2220
      Left            =   90
      OleObjectBlob   =   "Form2.frx":09FB
      TabIndex        =   2
      Top             =   315
      Width           =   8970
   End
   Begin VB.Label Label2 
      AutoSize        =   -1  'True
      Caption         =   "���� �������"
      Height          =   195
      Left            =   8190
      TabIndex        =   5
      Top             =   3015
      Width           =   855
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      Caption         =   "������ �������"
      Height          =   195
      Left            =   8100
      TabIndex        =   4
      Top             =   45
      Width           =   915
   End
End
Attribute VB_Name = "Form2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
Dim X  As String
X = InputBox("���� ��� ����� ��������")
Data1.RecordSource = "Select * From Customers where Name = '" + X + "'"
Data1.Refresh

End Sub

Private Sub Command2_Click()
Dim X As String
X = InputBox("���� ��� ���� ����� ��� �����")
Data2.RecordSource = "Select * From Move where Name = '" + X + "'"
Data2.Refresh
End Sub

Private Sub Command3_Click()
Dim X As String
X = InputBox("���� ���� �������")
Data1.RecordSource = X
Data1.Refresh
End Sub

Private Sub Command4_Click()
Data1.RecordSource = "Select Name As ����� From Customers"
Data1.Refresh
End Sub



Private Sub Command6_Click()

End Sub
