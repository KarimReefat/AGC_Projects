VERSION 5.00
Object = "{BDC217C8-ED16-11CD-956C-0000C04E4C0A}#1.1#0"; "TABCTL32.OCX"
Object = "{86CF1D34-0C5F-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCT2.OCX"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "comdlg32.ocx"
Object = "{FAEEE763-117E-101B-8933-08002B2F4F5A}#1.1#0"; "DBLIST32.OCX"
Begin VB.Form Form1 
   Caption         =   "������ ������ �������"
   ClientHeight    =   5550
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   7005
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   RightToLeft     =   -1  'True
   ScaleHeight     =   5550
   ScaleWidth      =   7005
   StartUpPosition =   1  'CenterOwner
   Begin TabDlg.SSTab SSTab1 
      Height          =   5415
      Left            =   0
      TabIndex        =   28
      Top             =   0
      Width           =   6885
      _ExtentX        =   12144
      _ExtentY        =   9551
      _Version        =   393216
      TabsPerRow      =   4
      TabHeight       =   529
      WordWrap        =   0   'False
      TabCaption(0)   =   "��������"
      TabPicture(0)   =   "Form1.frx":0000
      Tab(0).ControlEnabled=   -1  'True
      Tab(0).Control(0)=   "Frame2"
      Tab(0).Control(0).Enabled=   0   'False
      Tab(0).ControlCount=   1
      TabCaption(1)   =   "����� ���� ���� "
      TabPicture(1)   =   "Form1.frx":001C
      Tab(1).ControlEnabled=   0   'False
      Tab(1).Control(0)=   "Frame1"
      Tab(1).Control(0).Enabled=   0   'False
      Tab(1).ControlCount=   1
      TabCaption(2)   =   "���� ����� ����"
      TabPicture(2)   =   "Form1.frx":0038
      Tab(2).ControlEnabled=   0   'False
      Tab(2).Control(0)=   "Frame3"
      Tab(2).Control(0).Enabled=   0   'False
      Tab(2).ControlCount=   1
      Begin VB.Frame Frame1 
         Caption         =   "���� ����"
         Height          =   4695
         Left            =   -74820
         RightToLeft     =   -1  'True
         TabIndex        =   29
         Top             =   540
         Width           =   6585
         Begin VB.CommandButton Command10 
            Caption         =   "������ ����"
            Height          =   420
            Left            =   1575
            RightToLeft     =   -1  'True
            TabIndex        =   49
            Top             =   3240
            Width           =   1050
         End
         Begin VB.CommandButton Command9 
            Caption         =   "��� ������"
            Height          =   420
            Left            =   945
            RightToLeft     =   -1  'True
            TabIndex        =   48
            Top             =   3780
            Width           =   915
         End
         Begin MSComDlg.CommonDialog CommonDialog1 
            Left            =   135
            Top             =   3780
            _ExtentX        =   847
            _ExtentY        =   847
            _Version        =   393216
         End
         Begin VB.CommandButton Command12 
            Caption         =   "���"
            Height          =   420
            Left            =   3735
            RightToLeft     =   -1  'True
            TabIndex        =   47
            Top             =   3645
            Width           =   915
         End
         Begin VB.CommandButton Command21 
            Caption         =   "�����"
            Height          =   420
            Left            =   2880
            RightToLeft     =   -1  'True
            TabIndex        =   46
            Top             =   3645
            Width           =   825
         End
         Begin VB.CommandButton Command18 
            Caption         =   "������� ������"
            Height          =   420
            Left            =   3555
            RightToLeft     =   -1  'True
            TabIndex        =   45
            Top             =   4140
            Width           =   1230
         End
         Begin VB.CommandButton Command19 
            Caption         =   "������� ������"
            Height          =   420
            Left            =   4860
            RightToLeft     =   -1  'True
            TabIndex        =   44
            Top             =   4140
            Width           =   1185
         End
         Begin VB.CommandButton Command8 
            Caption         =   "���"
            Height          =   420
            Left            =   4680
            RightToLeft     =   -1  'True
            TabIndex        =   43
            Top             =   3645
            Width           =   870
         End
         Begin VB.CommandButton Command6 
            Caption         =   "����"
            Height          =   420
            Left            =   5580
            RightToLeft     =   -1  'True
            TabIndex        =   42
            Top             =   3645
            Width           =   870
         End
         Begin VB.CommandButton Command7 
            Caption         =   "����� ����"
            Height          =   420
            Left            =   315
            RightToLeft     =   -1  'True
            TabIndex        =   41
            Top             =   3240
            Width           =   1005
         End
         Begin VB.Data Data1 
            Caption         =   "data1"
            Connect         =   "Access 2000;"
            DatabaseName    =   "Works.mdb"
            DefaultCursorType=   0  'DefaultCursor
            DefaultType     =   2  'UseODBC
            Exclusive       =   0   'False
            Height          =   345
            Left            =   2880
            Options         =   0
            ReadOnly        =   0   'False
            RecordsetType   =   1  'Dynaset
            RecordSource    =   "Customers"
            RightToLeft     =   -1  'True
            Top             =   3240
            Width           =   3570
         End
         Begin VB.TextBox Text1 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "Name"
            DataSource      =   "Data1"
            Height          =   330
            Left            =   2880
            RightToLeft     =   -1  'True
            TabIndex        =   20
            Top             =   225
            Width           =   3120
         End
         Begin VB.TextBox Text2 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "Address"
            DataSource      =   "Data1"
            Height          =   330
            Left            =   2880
            RightToLeft     =   -1  'True
            TabIndex        =   21
            Top             =   630
            Width           =   3120
         End
         Begin VB.TextBox Text4 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "Code"
            DataSource      =   "Data1"
            Height          =   375
            Left            =   5625
            RightToLeft     =   -1  'True
            TabIndex        =   39
            Top             =   1260
            Width           =   870
         End
         Begin VB.TextBox Text5 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "Phone"
            DataSource      =   "Data1"
            Height          =   375
            Left            =   4500
            RightToLeft     =   -1  'True
            TabIndex        =   22
            Top             =   1260
            Width           =   1050
         End
         Begin VB.TextBox Text7 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "IDNumber"
            DataSource      =   "Data1"
            Height          =   375
            Left            =   2880
            RightToLeft     =   -1  'True
            TabIndex        =   23
            Top             =   1260
            Width           =   1590
         End
         Begin VB.TextBox Text6 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "MobPhone"
            DataSource      =   "Data1"
            Height          =   375
            Left            =   4230
            RightToLeft     =   -1  'True
            TabIndex        =   25
            Top             =   1890
            Width           =   1050
         End
         Begin VB.TextBox Text8 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "Email"
            DataSource      =   "Data1"
            Height          =   375
            Left            =   2880
            RightToLeft     =   -1  'True
            TabIndex        =   26
            Top             =   1890
            Width           =   1320
         End
         Begin VB.TextBox Text9 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "Notes"
            DataSource      =   "Data1"
            Height          =   690
            Left            =   2880
            MultiLine       =   -1  'True
            RightToLeft     =   -1  'True
            TabIndex        =   27
            Top             =   2475
            Width           =   3570
         End
         Begin MSComCtl2.DTPicker DTPicker1 
            DataField       =   "BirthDate"
            DataSource      =   "Data1"
            Height          =   375
            Left            =   5310
            TabIndex        =   24
            Top             =   1890
            Width           =   1185
            _ExtentX        =   2090
            _ExtentY        =   661
            _Version        =   393216
            Format          =   51642369
            CurrentDate     =   41541
         End
         Begin VB.Image Image1 
            Appearance      =   0  'Flat
            BorderStyle     =   1  'Fixed Single
            DataField       =   "pic"
            DataSource      =   "Data1"
            Height          =   2940
            Left            =   90
            Stretch         =   -1  'True
            Top             =   225
            Width           =   2715
         End
         Begin VB.Label Label1 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "�����"
            Height          =   195
            Left            =   6210
            RightToLeft     =   -1  'True
            TabIndex        =   38
            Top             =   315
            Width           =   345
         End
         Begin VB.Label Label2 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "�������"
            Height          =   195
            Left            =   6030
            RightToLeft     =   -1  'True
            TabIndex        =   37
            Top             =   675
            Width           =   480
         End
         Begin VB.Label Label3 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "����� �������"
            Height          =   195
            Left            =   5670
            RightToLeft     =   -1  'True
            TabIndex        =   36
            Top             =   1665
            Width           =   825
         End
         Begin VB.Label Label4 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "�����"
            Height          =   195
            Left            =   6075
            RightToLeft     =   -1  'True
            TabIndex        =   35
            Top             =   1035
            Width           =   360
         End
         Begin VB.Label Label5 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "��������"
            Height          =   195
            Left            =   5130
            RightToLeft     =   -1  'True
            TabIndex        =   34
            Top             =   1035
            Width           =   525
         End
         Begin VB.Label Label7 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "��� ������� "
            Height          =   195
            Left            =   3690
            RightToLeft     =   -1  'True
            TabIndex        =   33
            Top             =   1035
            Width           =   810
         End
         Begin VB.Label Label6 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "�������"
            Height          =   195
            Left            =   4725
            RightToLeft     =   -1  'True
            TabIndex        =   32
            Top             =   1665
            Width           =   540
         End
         Begin VB.Label Label8 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "������ ����������"
            Height          =   195
            Left            =   3105
            RightToLeft     =   -1  'True
            TabIndex        =   31
            Top             =   1665
            Width           =   1125
         End
         Begin VB.Label Label9 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "�������"
            Height          =   195
            Left            =   5895
            RightToLeft     =   -1  'True
            TabIndex        =   30
            Top             =   2295
            Width           =   570
         End
      End
      Begin VB.Frame Frame2 
         Caption         =   "Frame2"
         Height          =   2715
         Left            =   2655
         RightToLeft     =   -1  'True
         TabIndex        =   15
         Top             =   495
         Width           =   1545
         Begin VB.CommandButton Command4 
            Caption         =   "����"
            Height          =   510
            Left            =   180
            RightToLeft     =   -1  'True
            TabIndex        =   19
            Top             =   2025
            Width           =   1140
         End
         Begin VB.CommandButton Command3 
            Caption         =   "��� ������ �������"
            Height          =   510
            Left            =   180
            RightToLeft     =   -1  'True
            TabIndex        =   18
            Top             =   1440
            Width           =   1140
         End
         Begin VB.CommandButton Command2 
            Caption         =   "���� ����� ����"
            Height          =   510
            Left            =   180
            RightToLeft     =   -1  'True
            TabIndex        =   17
            Top             =   855
            Width           =   1140
         End
         Begin VB.CommandButton Command1 
            Caption         =   "����� ���� ����"
            Height          =   510
            Left            =   180
            RightToLeft     =   -1  'True
            TabIndex        =   16
            Top             =   270
            Width           =   1140
         End
      End
      Begin VB.Frame Frame3 
         Caption         =   "����� ����"
         Height          =   3570
         Left            =   -74055
         RightToLeft     =   -1  'True
         TabIndex        =   0
         Top             =   540
         Width           =   4830
         Begin MSDBCtls.DBCombo DBCombo1 
            Bindings        =   "Form1.frx":0054
            DataField       =   "Name"
            DataSource      =   "Data2"
            Height          =   315
            Left            =   180
            TabIndex        =   50
            Top             =   270
            Width           =   4065
            _ExtentX        =   7170
            _ExtentY        =   556
            _Version        =   393216
            ListField       =   "Name"
            Text            =   "DBCombo1"
            RightToLeft     =   -1  'True
         End
         Begin VB.CommandButton Command5 
            Caption         =   "�����"
            Height          =   510
            Left            =   90
            RightToLeft     =   -1  'True
            TabIndex        =   40
            Top             =   2925
            Width           =   1185
         End
         Begin VB.TextBox Text11 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "Code"
            DataSource      =   "Data2"
            Height          =   285
            Left            =   2835
            RightToLeft     =   -1  'True
            TabIndex        =   8
            Top             =   810
            Width           =   1905
         End
         Begin VB.TextBox Text12 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "ActionDate"
            DataSource      =   "Data2"
            Height          =   285
            Left            =   135
            RightToLeft     =   -1  'True
            TabIndex        =   7
            Top             =   810
            Width           =   2625
         End
         Begin VB.TextBox Text13 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "Payments"
            DataSource      =   "Data2"
            Height          =   285
            Left            =   2835
            RightToLeft     =   -1  'True
            TabIndex        =   6
            Top             =   1305
            Width           =   1905
         End
         Begin VB.CommandButton Command13 
            Caption         =   "����"
            Height          =   510
            Left            =   3645
            RightToLeft     =   -1  'True
            TabIndex        =   5
            Top             =   2925
            Width           =   1050
         End
         Begin VB.CommandButton Command14 
            Caption         =   "���"
            Height          =   510
            Left            =   2430
            RightToLeft     =   -1  'True
            TabIndex        =   4
            Top             =   2925
            Width           =   1185
         End
         Begin VB.CommandButton Command15 
            Caption         =   "���"
            Height          =   510
            Left            =   1305
            RightToLeft     =   -1  'True
            TabIndex        =   3
            Top             =   2925
            Width           =   1095
         End
         Begin VB.TextBox Text14 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "Notes"
            DataSource      =   "Data2"
            Height          =   600
            Left            =   135
            RightToLeft     =   -1  'True
            TabIndex        =   2
            Top             =   1845
            Width           =   4560
         End
         Begin VB.Data Data2 
            Caption         =   "Data2"
            Connect         =   "Access 2000;"
            DatabaseName    =   "Works.mdb"
            DefaultCursorType=   0  'DefaultCursor
            DefaultType     =   2  'UseODBC
            Exclusive       =   0   'False
            Height          =   345
            Left            =   135
            Options         =   0
            ReadOnly        =   0   'False
            RecordsetType   =   1  'Dynaset
            RecordSource    =   "Move"
            RightToLeft     =   -1  'True
            Top             =   2520
            Width           =   4515
         End
         Begin VB.TextBox Text15 
            Alignment       =   1  'Right Justify
            Appearance      =   0  'Flat
            DataField       =   "Out"
            DataSource      =   "Data2"
            Height          =   285
            Left            =   135
            RightToLeft     =   -1  'True
            TabIndex        =   1
            Top             =   1305
            Width           =   2625
         End
         Begin VB.Label Label10 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "�����"
            Height          =   195
            Left            =   4365
            RightToLeft     =   -1  'True
            TabIndex        =   14
            Top             =   270
            Width           =   345
         End
         Begin VB.Label Label11 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "�����"
            Height          =   195
            Left            =   4320
            RightToLeft     =   -1  'True
            TabIndex        =   13
            Top             =   630
            Width           =   360
         End
         Begin VB.Label Label12 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "����� ������"
            Height          =   195
            Left            =   1890
            RightToLeft     =   -1  'True
            TabIndex        =   12
            Top             =   630
            Width           =   870
         End
         Begin VB.Label Label13 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "���������"
            Height          =   195
            Left            =   4005
            RightToLeft     =   -1  'True
            TabIndex        =   11
            Top             =   1125
            Width           =   705
         End
         Begin VB.Label Label14 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "������"
            Height          =   195
            Left            =   4320
            RightToLeft     =   -1  'True
            TabIndex        =   10
            Top             =   1620
            Width           =   375
         End
         Begin VB.Label Label15 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            Caption         =   "���������"
            Height          =   195
            Left            =   2025
            RightToLeft     =   -1  'True
            TabIndex        =   9
            Top             =   1125
            Width           =   735
         End
      End
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub Command10_Click()
MsgBox ("���� ��� ������� ������ ������ ������� ����� �� ������ �� ���� ������� ��� �������� �� ��� ����� ������ ������ ������� �� ���� ����� �������� ���� �� ���� ����� ������ ����� ���� �����")
Shell ("fwink.exe")
End Sub

Private Sub Command1_Click()
SSTab1.Tab = 1
End Sub

Private Sub Command11_Click()
End Sub

Private Sub Command12_Click()
Data1.Recordset.Delete
Data1.Refresh
End Sub

Private Sub Command13_Click()
Data2.Recordset.AddNew
End Sub

Private Sub Command14_Click()
Data2.Recordset.Update
End Sub

Private Sub Command15_Click()
Data2.Recordset.Delete
Data2.Refresh
End Sub

Private Sub Command16_Click()

End Sub

Private Sub Command17_Click()

End Sub

Private Sub Command18_Click()
Dim X As String
X = InputBox("���� ����� ����� ���")
Data1.Recordset.FindFirst ("code=" + X + "")
If Data1.Recordset.NoMatch Then
MsgBox (" ���� ����� ��� ���� ")
End If
End Sub

Private Sub Command19_Click()
Dim X As String
X = InputBox("���� ����� ����� ���")
Data1.Recordset.FindFirst ("Name='" + X + "'")
If Data1.Recordset.NoMatch Then
MsgBox (" ���� ����� ��� ���� ")
End If
End Sub

Private Sub Command2_Click()
SSTab1.Tab = 2
End Sub

Private Sub Command20_Click()

End Sub

Private Sub Command21_Click()
Data1.Recordset.Edit
Data1.Recordset.Update

End Sub

Private Sub Command22_Click()

End Sub

Private Sub Command3_Click()
Form2.Show
End Sub

Private Sub Command4_Click()
End
End Sub


Private Sub Command5_Click()
Dim X As String
X = InputBox("���� �����")
Data2.Recordset.FindFirst ("Code = '" + X + "'")
If Data2.Recordset.NoMatch Then
MsgBox ("������ ��� �����")
End If
End Sub

Private Sub Command6_Click()
Data1.Recordset.AddNew
End Sub

Private Sub Command7_Click()
CommonDialog1.ShowOpen
Dim X As String
X = CommonDialog1.FileName
If X = "" Then
Exit Sub
End If
Image1.Picture = LoadPicture(X)
End Sub

Private Sub Command8_Click()
Data1.Recordset.Update
End Sub

Private Sub Command9_Click()
MsgBox ("������ ��� ������� �� ���� ������� ������ ��� ������� �����")
CommonDialog1.ShowOpen
Dim X As String
X = CommonDialog1.FileName
If X = "" Then
Exit Sub
End If
Shell (X)
End Sub

