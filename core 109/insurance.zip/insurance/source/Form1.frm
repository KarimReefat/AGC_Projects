VERSION 5.00
Object = "{86CF1D34-0C5F-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCT2.OCX"
Begin VB.Form Form1 
   Caption         =   "������ ���������"
   ClientHeight    =   5250
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4455
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   RightToLeft     =   -1  'True
   ScaleHeight     =   5250
   ScaleWidth      =   4455
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton Command3 
      Caption         =   "�������"
      Height          =   420
      Left            =   1980
      RightToLeft     =   -1  'True
      TabIndex        =   37
      Top             =   4725
      Width           =   825
   End
   Begin VB.TextBox Text9 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      DataField       =   "source"
      DataSource      =   "Data1"
      Height          =   375
      Left            =   1980
      Locked          =   -1  'True
      RightToLeft     =   -1  'True
      TabIndex        =   25
      Text            =   "Text6"
      Top             =   3375
      Width           =   555
   End
   Begin VB.TextBox Text8 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      DataField       =   "case"
      DataSource      =   "Data1"
      Height          =   375
      Left            =   1980
      Locked          =   -1  'True
      RightToLeft     =   -1  'True
      TabIndex        =   20
      Text            =   "Text6"
      Top             =   2925
      Width           =   555
   End
   Begin VB.TextBox Text7 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      DataField       =   "salary"
      DataSource      =   "Data1"
      Height          =   375
      Left            =   1980
      Locked          =   -1  'True
      RightToLeft     =   -1  'True
      TabIndex        =   15
      Text            =   "Text6"
      Top             =   2205
      Width           =   555
   End
   Begin VB.TextBox Text6 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      DataField       =   "age"
      DataSource      =   "Data1"
      Height          =   375
      Left            =   1980
      Locked          =   -1  'True
      RightToLeft     =   -1  'True
      TabIndex        =   10
      Text            =   "Text6"
      Top             =   1710
      Width           =   555
   End
   Begin VB.CommandButton Command2 
      Caption         =   "���"
      Height          =   420
      Left            =   2835
      RightToLeft     =   -1  'True
      TabIndex        =   31
      Top             =   4725
      Width           =   825
   End
   Begin VB.CommandButton Command1 
      Caption         =   "����"
      Height          =   420
      Left            =   3690
      RightToLeft     =   -1  'True
      TabIndex        =   30
      Top             =   4725
      Width           =   690
   End
   Begin VB.Data Data1 
      Caption         =   "Data1"
      Connect         =   "Access 2000;"
      DatabaseName    =   "insurance.mdb"
      DefaultCursorType=   0  'DefaultCursor
      DefaultType     =   2  'UseODBC
      Exclusive       =   0   'False
      Height          =   435
      Left            =   90
      Options         =   0
      ReadOnly        =   0   'False
      RecordsetType   =   1  'Dynaset
      RecordSource    =   "insurance"
      RightToLeft     =   -1  'True
      Top             =   4725
      Width           =   1860
   End
   Begin VB.Frame Frame5 
      Caption         =   "�������������"
      Height          =   600
      Left            =   90
      RightToLeft     =   -1  'True
      TabIndex        =   27
      Top             =   4050
      Width           =   1860
      Begin VB.OptionButton Option14 
         Alignment       =   1  'Right Justify
         Caption         =   "�����"
         Enabled         =   0   'False
         Height          =   240
         Left            =   90
         RightToLeft     =   -1  'True
         TabIndex        =   29
         Top             =   225
         Width           =   870
      End
      Begin VB.OptionButton Option13 
         Alignment       =   1  'Right Justify
         Caption         =   "�����"
         Enabled         =   0   'False
         Height          =   240
         Left            =   990
         RightToLeft     =   -1  'True
         TabIndex        =   28
         Top             =   225
         Width           =   735
      End
   End
   Begin VB.TextBox Text5 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      DataField       =   "total"
      DataSource      =   "Data1"
      Height          =   330
      Left            =   3465
      Locked          =   -1  'True
      RightToLeft     =   -1  'True
      TabIndex        =   26
      Text            =   "Text5"
      Top             =   4320
      Width           =   870
   End
   Begin MSComCtl2.DTPicker DTPicker1 
      DataField       =   "tdate"
      DataSource      =   "Data1"
      Height          =   285
      Left            =   2205
      TabIndex        =   4
      Top             =   1215
      Width           =   2130
      _ExtentX        =   3757
      _ExtentY        =   503
      _Version        =   393216
      Format          =   88408065
      CurrentDate     =   41558
   End
   Begin VB.TextBox Text4 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      DataField       =   "Phone"
      DataSource      =   "Data1"
      Height          =   285
      Left            =   90
      RightToLeft     =   -1  'True
      TabIndex        =   5
      Text            =   "Text1"
      Top             =   1215
      Width           =   2085
   End
   Begin VB.TextBox Text3 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      DataField       =   "Address"
      DataSource      =   "Data1"
      Height          =   285
      Left            =   45
      RightToLeft     =   -1  'True
      TabIndex        =   3
      Text            =   "Text1"
      Top             =   675
      Width           =   3615
   End
   Begin VB.TextBox Text2 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      DataField       =   "job"
      DataSource      =   "Data1"
      Height          =   285
      Left            =   45
      RightToLeft     =   -1  'True
      TabIndex        =   2
      Text            =   "Text1"
      Top             =   360
      Width           =   3615
   End
   Begin VB.TextBox Text1 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      DataField       =   "SName"
      DataSource      =   "Data1"
      Height          =   285
      Left            =   45
      RightToLeft     =   -1  'True
      TabIndex        =   1
      Text            =   "Text1"
      Top             =   45
      Width           =   3615
   End
   Begin VB.Frame Frame4 
      Caption         =   "���� �������"
      Height          =   1185
      Left            =   135
      RightToLeft     =   -1  'True
      TabIndex        =   21
      Top             =   2790
      Width           =   1770
      Begin VB.OptionButton Option12 
         Alignment       =   1  'Right Justify
         Caption         =   "�����"
         Height          =   285
         Left            =   855
         RightToLeft     =   -1  'True
         TabIndex        =   22
         Top             =   225
         Width           =   735
      End
      Begin VB.OptionButton Option11 
         Alignment       =   1  'Right Justify
         Caption         =   "�����"
         Height          =   285
         Left            =   765
         RightToLeft     =   -1  'True
         TabIndex        =   23
         Top             =   540
         Width           =   825
      End
      Begin VB.OptionButton Option10 
         Alignment       =   1  'Right Justify
         Caption         =   "����"
         Height          =   285
         Left            =   810
         RightToLeft     =   -1  'True
         TabIndex        =   24
         Top             =   855
         Width           =   780
      End
   End
   Begin VB.Frame Frame3 
      Caption         =   "������ ����������"
      Height          =   1230
      Left            =   2565
      RightToLeft     =   -1  'True
      TabIndex        =   16
      Top             =   2790
      Width           =   1770
      Begin VB.OptionButton Option9 
         Alignment       =   1  'Right Justify
         Caption         =   "����"
         Height          =   285
         Left            =   945
         RightToLeft     =   -1  'True
         TabIndex        =   17
         Top             =   225
         Width           =   690
      End
      Begin VB.OptionButton Option8 
         Alignment       =   1  'Right Justify
         Caption         =   "�����"
         Height          =   285
         Left            =   810
         RightToLeft     =   -1  'True
         TabIndex        =   18
         Top             =   540
         Width           =   825
      End
      Begin VB.OptionButton Option7 
         Alignment       =   1  'Right Justify
         Caption         =   "����� �����"
         Height          =   285
         Left            =   360
         RightToLeft     =   -1  'True
         TabIndex        =   19
         Top             =   855
         Width           =   1275
      End
   End
   Begin VB.Frame Frame2 
      Caption         =   "������"
      Height          =   1095
      Left            =   90
      RightToLeft     =   -1  'True
      TabIndex        =   11
      Top             =   1575
      Width           =   1815
      Begin VB.OptionButton Option6 
         Alignment       =   1  'Right Justify
         Caption         =   "�� 1500 ��� 2500"
         Height          =   285
         Left            =   90
         RightToLeft     =   -1  'True
         TabIndex        =   12
         Top             =   180
         Width           =   1635
      End
      Begin VB.OptionButton Option5 
         Alignment       =   1  'Right Justify
         Caption         =   "�� 2501 ��� 5000"
         Height          =   285
         Left            =   90
         RightToLeft     =   -1  'True
         TabIndex        =   13
         Top             =   450
         Width           =   1635
      End
      Begin VB.OptionButton Option4 
         Alignment       =   1  'Right Justify
         Caption         =   "���� �� 5000"
         Height          =   285
         Left            =   315
         RightToLeft     =   -1  'True
         TabIndex        =   14
         Top             =   720
         Width           =   1410
      End
   End
   Begin VB.Frame Frame1 
      Caption         =   "����"
      Height          =   1095
      Left            =   2565
      RightToLeft     =   -1  'True
      TabIndex        =   6
      Top             =   1575
      Width           =   1815
      Begin VB.OptionButton Option3 
         Alignment       =   1  'Right Justify
         Caption         =   "���� �� 51 ��� 60"
         Height          =   285
         Left            =   45
         RightToLeft     =   -1  'True
         TabIndex        =   9
         Top             =   720
         Width           =   1635
      End
      Begin VB.OptionButton Option2 
         Alignment       =   1  'Right Justify
         Caption         =   "���� �� 31 ��� 50"
         Height          =   285
         Left            =   45
         RightToLeft     =   -1  'True
         TabIndex        =   8
         Top             =   450
         Width           =   1635
      End
      Begin VB.OptionButton Option1 
         Alignment       =   1  'Right Justify
         Caption         =   "���� �� 1 ��� 30 "
         Height          =   285
         Left            =   90
         RightToLeft     =   -1  'True
         TabIndex        =   7
         Top             =   180
         Width           =   1590
      End
   End
   Begin VB.Label Label6 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      Caption         =   "����� ������"
      Height          =   195
      Left            =   3465
      TabIndex        =   36
      Top             =   4095
      Width           =   885
   End
   Begin VB.Label Label5 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      Caption         =   "��� ��������"
      Height          =   195
      Left            =   1305
      TabIndex        =   35
      Top             =   990
      Width           =   810
   End
   Begin VB.Label Label4 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      Caption         =   "�������"
      Height          =   195
      Left            =   3915
      TabIndex        =   34
      Top             =   990
      Width           =   465
   End
   Begin VB.Label Label3 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      Caption         =   "�������"
      Height          =   195
      Left            =   3885
      TabIndex        =   33
      Top             =   630
      Width           =   480
   End
   Begin VB.Label Label2 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      Caption         =   "�������"
      Height          =   195
      Left            =   3960
      TabIndex        =   32
      Top             =   360
      Width           =   495
   End
   Begin VB.Label Label1 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      Caption         =   ":��� ������ "
      Height          =   195
      Left            =   3690
      TabIndex        =   0
      Top             =   45
      Width           =   810
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
Data1.Recordset.AddNew
Option1.Value = False
Option2.Value = False
Option3.Value = False
Option4.Value = False
Option5.Value = False
Option6.Value = False
Option7.Value = False
Option8.Value = False
Option9.Value = False
Option10.Value = False
Option11.Value = False
Option12.Value = False
Option13.Value = False
Option14.Value = False
End Sub

Private Sub Command2_Click()
If Option1.Value = True Then
Data1.Recordset(4) = 3
End If
If Option2.Value = True Then
Data1.Recordset(4) = 2
End If
If Option3.Value = True Then
Data1.Recordset(4) = 1
End If

If Option4.Value = True Then
Data1.Recordset(7) = 3
End If
If Option5.Value = True Then
Data1.Recordset(7) = 2
End If
If Option6.Value = True Then
Data1.Recordset(7) = 1
End If

If Option7.Value = True Then
Data1.Recordset(8) = 1
End If
If Option8.Value = True Then
Data1.Recordset(8) = 2
End If
If Option9.Value = True Then
Data1.Recordset(8) = 3
End If

If Option10.Value = True Then
Data1.Recordset(9) = 1
End If
If Option11.Value = True Then
Data1.Recordset(9) = 2
End If
If Option12.Value = True Then
Data1.Recordset(9) = 3
End If

Text5.Text = Val(Text6.Text) + Val(Text7.Text) + Val(Text8.Text) + Val(Text9.Text)

Data1.Recordset.Update

End Sub

Private Sub Command3_Click()
Form2.Show
Form1.Hide

End Sub

Private Sub Form_Load()

End Sub

Private Sub Option1_Click()
Text6.Text = 3
End Sub

Private Sub Option10_Click()
Text9.Text = 1
End Sub

Private Sub Option11_Click()
Text9.Text = 2
End Sub

Private Sub Option12_Click()
Text9.Text = 3
End Sub

Private Sub Option2_Click()
Text6.Text = 2
End Sub

Private Sub Option3_Click()
Text6.Text = 1
End Sub

Private Sub Option4_Click()
Text7.Text = 3
End Sub

Private Sub Option5_Click()
Text7.Text = 2
End Sub

Private Sub Option6_Click()
Text7.Text = 1
End Sub

Private Sub Option7_Click()
Text8.Text = 1
End Sub

Private Sub Option8_Click()
Text8.Text = 2
End Sub

Private Sub Option9_Click()
Text8.Text = 3
End Sub

Private Sub Text5_Change()
If Val(Text5.Text) <= 6 Then
Option14.Value = True
End If
If Val(Text5.Text) > 6 Then
Option13.Value = True
End If
End Sub

Private Sub Text6_Change()
If Val(Text6.Text) = 3 Then
Option1.Value = True
End If
If Val(Text6.Text) = 2 Then
Option2.Value = True
End If
If Val(Text6.Text) = 1 Then
Option3.Value = True
End If
End Sub

Private Sub Text7_Change()
If Val(Text7.Text) = 3 Then
Option4.Value = True
End If
If Val(Text7.Text) = 2 Then
Option5.Value = True
End If
If Val(Text7.Text) = 1 Then
Option6.Value = True
End If
End Sub

Private Sub Text8_Change()
If Val(Text8.Text) = 3 Then
Option9.Value = True
End If
If Val(Text8.Text) = 2 Then
Option8.Value = True
End If
If Val(Text8.Text) = 1 Then
Option7.Value = True
End If
End Sub

Private Sub Text9_Change()
If Val(Text9.Text) = 3 Then
Option12.Value = True
End If
If Val(Text9.Text) = 2 Then
Option11.Value = True
End If
If Val(Text9.Text) = 1 Then
Option10.Value = True
End If
End Sub
