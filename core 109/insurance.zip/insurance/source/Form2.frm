VERSION 5.00
Object = "{00028C01-0000-0000-0000-000000000046}#1.0#0"; "DBGRID32.OCX"
Begin VB.Form Form2 
   Caption         =   "���������"
   ClientHeight    =   3945
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   7890
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   RightToLeft     =   -1  'True
   ScaleHeight     =   3945
   ScaleWidth      =   7890
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton Command3 
      Caption         =   "��� �������"
      Height          =   510
      Left            =   4455
      RightToLeft     =   -1  'True
      TabIndex        =   3
      Top             =   3330
      Width           =   1230
   End
   Begin VB.CommandButton Command2 
      Caption         =   "��� ��� ��������"
      Height          =   510
      Left            =   3195
      RightToLeft     =   -1  'True
      TabIndex        =   2
      Top             =   3330
      Width           =   1230
   End
   Begin VB.CommandButton Command1 
      Caption         =   "��� ��������"
      Height          =   510
      Left            =   1935
      RightToLeft     =   -1  'True
      TabIndex        =   1
      Top             =   3330
      Width           =   1230
   End
   Begin VB.Data Data1 
      Caption         =   "Data1"
      Connect         =   "Access 2000;"
      DatabaseName    =   "insurance.mdb"
      DefaultCursorType=   0  'DefaultCursor
      DefaultType     =   2  'UseODBC
      Exclusive       =   0   'False
      Height          =   345
      Left            =   135
      Options         =   0
      ReadOnly        =   0   'False
      RecordsetType   =   1  'Dynaset
      RecordSource    =   "insurance"
      RightToLeft     =   -1  'True
      Top             =   2880
      Width           =   7305
   End
   Begin MSDBGrid.DBGrid DBGrid1 
      Bindings        =   "Form2.frx":0000
      Height          =   2805
      Left            =   45
      OleObjectBlob   =   "Form2.frx":0014
      TabIndex        =   0
      Top             =   45
      Width           =   7710
   End
End
Attribute VB_Name = "Form2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
Dim x As String
x = "select * from insurance where total > 6"
Data1.RecordSource = x
Data1.Refresh

End Sub

Private Sub Command2_Click()
Dim x As String
x = "select * from insurance where total <= 6"
Data1.RecordSource = x
Data1.Refresh
End Sub

Private Sub Command3_Click()
Dim x As String
x = "select * from insurance"
Data1.RecordSource = x
Data1.Refresh
End Sub

Private Sub Command4_Click()
Dim a As String
Dim b As String
Dim c As Date
a = DTPicker1.Value
'c = #02:01:1900#
b = "select * from insurance where tdate => #1/1/1900#"
Data1.RecordSource = b
Data1.Refresh

End Sub
