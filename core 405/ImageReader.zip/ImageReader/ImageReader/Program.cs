﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Text;
using System.IO;

namespace ImageReader
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // the code for showing the form1 or the first form in the program
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());

        }
    }

    // the main class inside it we take the path of the image files
    // and it's directory and return the object that will deal with 
    // this files. 
    abstract class Assistan:IDisposable
    {
        string imgPath;
        public string ImgPath
        {
            get { return imgPath; }
            set { imgPath = value; }
        }
        Dictionary<int, string> imgList
            = new Dictionary<int, string>();

        public Dictionary<int, string> ImgList
        {
            get { return imgList; }
            //set { imgList = value; }
        }
        public int currentImgNo;

        public Assistan(string _imgPath)
        {
            imgPath = _imgPath;

            // Split the path
            string[] splitter = _imgPath.Split('\\');
            StringBuilder dir = new StringBuilder();

            // rebuild the direcotyr path
            for (int i = 0; i < splitter.Count() - 1; i++)
            {
                dir.Append(splitter[i] + "\\");
            }
            // Get All files(images)   
            if (!Directory.Exists(dir.ToString()))
                throw new DirectoryNotFoundException();
            // Get all files(images)
            string[] files = Directory.GetFiles(dir.ToString());

            imgList.Clear(); //Optional

            for (int i = 0; i < files.Count(); i++)
            {
                // check of the file type is not an image(.jpg) ignore it.
                string file = files[i];
                string extn = file.Split('.').Last(); // if(exten == "jpg"
                if(extn == "jpg")
                // add image key and value(path)
                imgList.Add(i, files[i]);
                // add current image number
                if (files[i] == imgPath)
                    currentImgNo = i;
            }
        }

        public virtual void Dispose()
        {
            /* dispose method will act when the deconstract get execute or 
            * when the object is delete from memory 
            * */

            // the SuppressFinalize is use to make assure that 
            // the dispose method will only run one time not twice
            GC.SuppressFinalize(this);

            // the collect method to call the garbage collection and the gc.GetGeneration
            // is used to Returns the current generation number of an object and the 
            // GCCollectionMode.Forced is used to Forces the garbage collection to occur immediately
            GC.Collect(GC.GetGeneration(this), GCCollectionMode.Forced);
        }
        ~Assistan()
        {
            // the calling of the garbage collection to this class and the destructor
            this.Dispose();
        }
    }

    public enum PlayMode
    {
        Next, Back
    }

    /* in this class we get the properties of the image file
     * and we use it to move inside the the image folder and 
     * change the current image 
     * */
    class Reader : Assistan
    {
        public Reader(string path):base(path)
        {
            // in the reader constractor we call the assistan constractor and
            // give it the path of the image file 
        }

        public string PlayImage(PlayMode mode)
        {
            // this is the code to switch between images 
            switch (mode)
            {
                case PlayMode.Next:
                    // if we press the next key it will check the image index
                    // if it less than the count of the number of image files 
                    // in the folder it will increase the image count by one
                    if (currentImgNo < ImgList.Count - 1)
                        currentImgNo++;
                    // else it will give us the first image so when it reach the 
                    // end of the files it will start over again. 
                    else
                        currentImgNo = 0;
                    break;
                case PlayMode.Back:
                    // and the same with the back button when it reach the first file
                    // it will start over from the last file in the folder 
                    if (currentImgNo > 0)
                        currentImgNo--;
                    else currentImgNo = ImgList.Count;
                    break;
            }
            // we get the path of the current image from the dictionary and return this path
            // to the caller of the object or the next or back buttons.
            ImgPath = ImgList[currentImgNo];
            return ImgPath;
        }

        // this function will return the properties of the file
        // as object of the PropertiesType class 
        public PropertiesType GetProperties()
        {
            // first we declare variable of the type fileinfo
            // to get the properties of the image file
            FileInfo inf =
                new FileInfo(ImgPath);

            // we make object of the PropertiesType class
            // that will be the return value of this fucntion
            PropertiesType pro = new PropertiesType();

            // we assing the four value of the image properties
            // to the object and then return the function
            pro.Name = inf.Name;
            pro.imgPath = ImgPath;
            pro.size = inf.Length / 1024; // size in kb
            pro.create = inf.CreationTime;
            return pro;
        }

        public override void Dispose()
        {
            /* dispose method will act when the deconstract get execute or 
             * when the object is delete from memory 
             * */

            // the SuppressFinalize is use to make assure that 
            // the dispose method will only run one time not twice
            GC.SuppressFinalize(this);

            // the collect method to call the garbage collection and the gc.GetGeneration
            // is used to Returns the current generation number of an object and the 
            // GCCollectionMode.Forced is used to Forces the garbage collection to occur immediately
            GC.Collect(GC.GetGeneration(this), GCCollectionMode.Forced);
        }
        ~Reader()
        {
            // the calling of the garbage collection to this class and the destructor
            this.Dispose();
        }
       
    }

    /* the class is use to get the Properties of the file image */
    class PropertiesType: IDisposable   
    {
        // this variable are use to save the image properties
        public string imgPath;
        public string Name;
        public float size;
        public DateTime create;

        public void Dispose()
        {
            /* dispose method will act when the deconstract get execute or 
             * when the object is delete from memory 
             * */
 
            // the SuppressFinalize is use to make assure that 
            // the dispose method will only run one time not twice
            GC.SuppressFinalize(this);
            
            // the collect method to call the garbage collection and the gc.GetGeneration
            // is used to Returns the current generation number of an object and the 
            // GCCollectionMode.Forced is used to Forces the garbage collection to occur immediately 
            GC.Collect(GC.GetGeneration(this), GCCollectionMode.Forced);
        }
        ~PropertiesType()
        {
            // the calling of the garbage collection to this class and the destructor
            this.Dispose();
        }
    }


}
