﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace ImageReader
{
    public partial class Form1 : Form
    {
        Reader rd;
        imgProperties fm;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // change image to the next image if will only run if the user open image file
            // from the menu and select image file if not it will not run
            if (rd != null)
            {
                rd.PlayImage(PlayMode.Next);
                pictureBox1.ImageLocation = rd.ImgPath;
            }
                // in case he press the button before choose image file 
                // it give a message for that
            else
                MessageBox.Show("You must choose image first");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // change image to the back image if will only run if the user open image file
            // from the menu and select image file if not it will not run
            if (rd != null)
            {
                rd.PlayImage(PlayMode.Next);
                pictureBox1.ImageLocation = rd.ImgPath;              
            }
            // in case he press the button before choose image file 
            // it give a message for that
            else
                MessageBox.Show("You must choose image first");
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {            
            // the code of the open dailog to open the image file if the user
            // press other key other than ok it will not run
            if (openFile.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                // next we take object from the reader class and send to it
                // the path to the image file and then change the image of 
                // the picture box to the choosen image
                rd = new Reader(openFile.FileName);
                pictureBox1.ImageLocation = rd.ImgPath;
            }
            // in case he press the button before choose image file 
            // it give a message for that
            else
                MessageBox.Show("You must choose image first");

        }

        private void propertiesAltEnterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // the code to show the properties form of the current image
            // first it check to see if the rd or the reader class object 
            // is not empty if not it will continue if it's empty it mean
            // that no image file selected
            if (rd != null)
            {
                // next it take object from the ProperitesType class that
                // already have the current image properties 
                PropertiesType pro = rd.GetProperties();
                
                // next we make new object of the properites form and send the image
                // properties to it and then show the form.
                fm = new imgProperties(pro.imgPath,pro.Name, pro.size, pro.create);
                fm.ShowDialog();
            }
            // in case he press the button before choose image file 
            // it give a message for that
            else
                MessageBox.Show("You must choose image first");
        }

        private void closeCtrlXToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // the code to close the application
            this.Dispose();
        }

        private void nextAltRightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // change image to the next image if will only run if the user open image file
            // from the menu and select image file if not it will not run
            if (rd != null)
            {
                rd.PlayImage(PlayMode.Next);
                pictureBox1.ImageLocation = rd.ImgPath;
            }
            // in case he press the button before choose image file 
            // it give a message for that
            else
                MessageBox.Show("You must choose image first");
        }

        private void backAltLeftToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // change image to the back image if will only run if the user open image file
            // from the menu and select image file if not it will not run
            if (rd != null)
            {
                rd.PlayImage(PlayMode.Next);
                pictureBox1.ImageLocation = rd.ImgPath;
            }
            // in case he press the button before choose image file 
            // it give a message for that
            else
                MessageBox.Show("You must choose image first");
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        { 
            /* theis code that will handeled the key press event and it
             * will trigger the commandos that will deal with the program 
             * */
            
            // first i take the keyChar or the key Accii of the pressed key
           int a = e.KeyChar;

            // if it's 4 it mean the ctrl+d have press so the next button 
            // will perform the click event 
           if (a == 4)
               button2.PerformClick();
           // if it's 1 it mean the ctrl+a have press so the back button 
           // will perform the click event
           else if (a == 1)
               button1.PerformClick();
           // if it's 15 it mean the ctrl+o have press so the open file  
           // will perform the click event
           else if (a == 15)
               openToolStripMenuItem.PerformClick();
           // if it's 10 it mean the ctrl+enter have press so the properties  
           // will perform the click event
           else if (a == 10)
               propertiesAltEnterToolStripMenuItem.PerformClick();
           // if it's 24 it mean the ctrl+x have press so the close button 
           // will perform the click event
           else if (a == 24)
               closeCtrlXToolStripMenuItem.PerformClick();                      
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // the pcitre box take the foucs after the form load
            pictureBox1.Select();
        }
    }
}
