﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ImageReader
{
    public partial class imgProperties : Form
    {
        public imgProperties(string path, string name, float size, DateTime create)
        {
            // this is the first method to initialize the properties form
            InitializeComponent();

            // after the initialize it will take the variables that will
            // have the properties of the images like it's path and name
            // and it's creation time and it's size.
            pcSample.ImageLocation = path;
            lblname.Text = name;
            lblSize.Text = size.ToString() + " KB";
            lblCreate.Text = create.ToString();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // this is the code to close the properties form after 
            // press the ok button 
            this.Close();

        }
    }
}
