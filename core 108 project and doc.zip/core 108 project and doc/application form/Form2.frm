VERSION 5.00
Begin VB.Form Form2 
   Caption         =   "Form1"
   ClientHeight    =   7800
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   10440
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   Picture         =   "Form2.frx":0000
   ScaleHeight     =   7800
   ScaleWidth      =   10440
   StartUpPosition =   1  'CenterOwner
   Begin VB.CheckBox Check7 
      Caption         =   "Check7"
      Height          =   225
      Left            =   2460
      TabIndex        =   22
      Top             =   5640
      Width           =   225
   End
   Begin VB.CheckBox Check6 
      Caption         =   "Check6"
      Height          =   195
      Left            =   2460
      TabIndex        =   21
      Top             =   5400
      Width           =   225
   End
   Begin VB.CheckBox Check5 
      Caption         =   "Check5"
      Height          =   255
      Left            =   2460
      TabIndex        =   20
      Top             =   5130
      Width           =   225
   End
   Begin VB.CheckBox Check4 
      Caption         =   "Check4"
      Height          =   225
      Left            =   1770
      TabIndex        =   19
      Top             =   4590
      Width           =   225
   End
   Begin VB.CheckBox Check3 
      Caption         =   "Check3"
      Height          =   255
      Left            =   3240
      TabIndex        =   18
      Top             =   4590
      Width           =   225
   End
   Begin VB.CheckBox Check2 
      Caption         =   "Check2"
      Height          =   225
      Left            =   1770
      TabIndex        =   17
      Top             =   4140
      Width           =   255
   End
   Begin VB.CheckBox Check1 
      Caption         =   "Check1"
      Height          =   225
      Left            =   3240
      TabIndex        =   16
      Top             =   4140
      Width           =   255
   End
   Begin VB.TextBox Text16 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFC0&
      BorderStyle     =   0  'None
      Height          =   315
      Left            =   1770
      TabIndex        =   15
      Top             =   7260
      Width           =   7350
   End
   Begin VB.TextBox Text15 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFC0&
      BorderStyle     =   0  'None
      Height          =   255
      Left            =   900
      TabIndex        =   14
      Top             =   6900
      Width           =   2670
   End
   Begin VB.TextBox Text14 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFC0&
      BorderStyle     =   0  'None
      Height          =   255
      Left            =   6570
      TabIndex        =   13
      Top             =   6900
      Width           =   2670
   End
   Begin VB.TextBox Text13 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFC0&
      BorderStyle     =   0  'None
      Height          =   285
      Left            =   1920
      TabIndex        =   12
      Top             =   6540
      Width           =   5535
   End
   Begin VB.TextBox Text12 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFC0&
      BorderStyle     =   0  'None
      Height          =   285
      Left            =   1620
      TabIndex        =   11
      Top             =   6180
      Width           =   7380
   End
   Begin VB.TextBox Text11 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFC0&
      BorderStyle     =   0  'None
      Height          =   285
      Left            =   6420
      TabIndex        =   10
      Top             =   5310
      Width           =   2985
   End
   Begin VB.TextBox Text10 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFC0&
      BorderStyle     =   0  'None
      Height          =   285
      Left            =   6390
      TabIndex        =   9
      Top             =   4980
      Width           =   3015
   End
   Begin VB.TextBox Text9 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFC0&
      BorderStyle     =   0  'None
      Height          =   240
      Left            =   6420
      TabIndex        =   8
      Top             =   4650
      Width           =   2985
   End
   Begin VB.TextBox Text8 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFC0&
      BorderStyle     =   0  'None
      Height          =   255
      Left            =   6390
      TabIndex        =   7
      Top             =   4290
      Width           =   2985
   End
   Begin VB.TextBox Text7 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFC0&
      BorderStyle     =   0  'None
      Height          =   330
      Left            =   6420
      TabIndex        =   6
      Top             =   3870
      Width           =   2985
   End
   Begin VB.TextBox Text6 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFC0&
      BorderStyle     =   0  'None
      Height          =   285
      Left            =   1410
      TabIndex        =   5
      Top             =   3480
      Width           =   3345
   End
   Begin VB.TextBox Text5 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFC0&
      BorderStyle     =   0  'None
      Height          =   285
      Left            =   6360
      TabIndex        =   4
      Top             =   3480
      Width           =   3030
   End
   Begin VB.TextBox Text4 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFC0&
      BorderStyle     =   0  'None
      Height          =   375
      Left            =   1290
      TabIndex        =   3
      Top             =   3030
      Width           =   8055
   End
   Begin VB.TextBox Text3 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFC0&
      BorderStyle     =   0  'None
      Height          =   255
      Left            =   1680
      TabIndex        =   2
      Top             =   2160
      Width           =   3495
   End
   Begin VB.TextBox Text2 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFC0&
      BorderStyle     =   0  'None
      Height          =   285
      Left            =   7890
      TabIndex        =   1
      Top             =   1890
      Width           =   1215
   End
   Begin VB.TextBox Text1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFC0&
      BorderStyle     =   0  'None
      Height          =   240
      Left            =   1230
      TabIndex        =   0
      Top             =   1800
      Width           =   3315
   End
End
Attribute VB_Name = "Form2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
