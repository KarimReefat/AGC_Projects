﻿Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        ' كود اظهار شاشة اسم عميل جديد
        Form2.ShowDialog()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        ' الكود التالي مسئول عن اولاً: إظهار مربع نص من اجل ادخال رقم الاي ديه
        ' بعد ذلك يقوم الكود بإرسال القيمة التى قام المستخدم بادخالها الي الدالة 
        ' only_integer
        ' من اجل العودة بالارقام التى تكون داخل النص وذلك علي فرض انه ادخل
        ' الايديه وبه رموز خطأ او به رموز اضافية فتقوم الدالة باستخراج 
        ' الرقم من داخل النص الذى يقوم المستخدم بكتابته بعد ذلك نقوم باستخدام
        ' CStr
        ' من اجل تحويل الرقم الذى تعود به الدالة الي نص مرة اخري ويتم حفظه في المتغير
        ' b
        Dim b As String = CStr(only_integer(InputBox("Please Enter ID Number", "Search")))

        ' بعد ذلك يتم التأكد نقوم بفحص اذا كان المستخدم 
        ' بالضغط علي مسافة بدلاً من ان يدخل الرقم او انه قام 
        ' بالضغط علي مفتاح اوكيه او كانسيل بدلاً من ان يدخل 
        ' رقم فيقوم الكود بفحص ذلك ويظهر رسالة خطأ ويخرج من الصب
        If Len(Trim(b)) = 0 Or Val(b) = 0 Then
            MsgBox("Wrong Id")
            Exit Sub
        End If

        ' يتم فتح الاتصال مع الجدول العملاء ويتم البحث عن رقم العميل
        rs.Open("Select * From Customers Where Id = '" + b + "'", cn)

        ' في حالة عدم العثور علي رقم العميل فهذا يدل علي عدم وجوده
        ' داخل الجدول فيتم اظهار رسالة تفيد ذلك ويتم ايقاف الاتصال 
        ' مع الجدول ويتم الخروج من البرنامج الفرعي الصب 
        If rs.EOF Or rs.BOF Then
            MsgBox("Cusomer Not Found", MsgBoxStyle.Critical)
            rs.Close()
            Exit Sub
        End If

        ' في حالة العثور علي رقم الايديه للعميل فيتم فتح الاتصال
        ' مع جدول توتلاز من اجل الاستعلام عن قيمة النقود في الحساب
        '  الخاص بالعميل وتظهر هذه القيمة في الشاشة القادمة
        rs1.Open("Select * From Totals where CustomerId = '" + b + "'", cn)

        ' الكود الخاص باظهار الشاشة الخاصة ببيانات العميل وذلك دليل علي العثور عليه
        Form3.ShowDialog()

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click

        ' يتم اظهار المفاتيح الخاصة بشاشة التقارير من اجل الاستعلام عن التقارير المختلفة
        Form6.Button2.Show()
        Form6.Button3.Show()
        Form6.Button4.Show()
        Form6.Button5.Show()

        ' الكود المسئول عن اظهار شاشة التقارير
        Form6.ShowDialog()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click

        ' كود انهاء البرنامج
        End

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' كود فتح الاتصال مع قاعدة البيانات ويأخذ نص البروفيدر من الموديل 
        cn.Open(con)

    End Sub

End Class
