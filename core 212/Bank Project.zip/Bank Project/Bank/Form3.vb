﻿Public Class Form3

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        ' كود فتح شاشة الايداع
        Form4.ShowDialog()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        ' كود فتح شاشة السحب
        Form5.ShowDialog()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        ' كود التأكد من اغلاق الار اس قبل فتحها مرة اخري
        If rs.State = 1 Then
            rs.Close()
        End If

        ' كود الاستعلام عن طريق الرقم الاي ديه الخاص بالعميل
        rs.CursorLocation = ADODB.CursorLocationEnum.adUseClient
        rs.CursorType = ADODB.CursorTypeEnum.adOpenKeyset
        rs.Open("Select * From Actions Where CustomerId = '" & i & "'", cn)

        ' يتم توصيل شاشة التقارير بالار اس الخاص بالعميل المستعلم عنه
        Form6.AxDataGrid1.DataSource = rs

        '  اخفاء المفاتيح الخاص بشاشة التقارير التى لا يتم التعامل معها
        Form6.Button2.Hide()
        Form6.Button3.Hide()
        Form6.Button4.Hide()
        Form6.Button5.Hide()

        ' كود فتح شاشة حركات العميل
        Form6.ShowDialog()
    End Sub

    Private Sub Form3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ' ادخال رقم الايديه للعميل في المتغير ثم ادخال بيانات العميل في مربعات النص
        i = rs("ID").Value
        TextBox1.Text = rs("FirstName").Value
        TextBox2.Text = rs("LastName").Value
        TextBox3.Text = rs("Mobile").Value
        TextBox4.Text = rs("Email").Value
        GroupBox1.Text = "Account ID: " & i

        ' يقوم الكود بالتأكد من انه قد تم العثور علي العميل 
        ' فيتم اظهار قيمة المبلغ الموجود بحساب هذا العميل 
        ' في مربع النص الخاص بالمبلغ وفى حالة عدم العثور عليه 
        ' يتم اظهار القيمة صفر
        If rs1.EOF Or rs1.BOF Then
            TextBox5.Text = "0"
        Else
            TextBox5.Text = rs1("Net").Value
        End If

        ' كود اغلاق الاتصال مع الجداول 
        rs.Close()
        rs1.Close()

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click

        ' الكود المسئول عن التأكد من عدم 
        '  وجود مربعات نص خالية عندما يتم الضغط علي مفتاح 
        ' ابديت ويتم هنا اخذ نسخة من الادوات الموجودة داخل 
        ' الجروب الي المتغير سي ثم يتم فحص اولاً نوعية الاداة 
        ' عن طريق الدالة تايب نيم وبعد التأكد من ان نوع 
        '  الاداة هو مربع نص يتم التأكد من انها خالية من البيانات
        ' وفى تلك الحالة يتم اظهار رسالة تفيد بعدم امكانية عمل التحديث
        ' ويتم ايقاف المؤشر علي مربع النص الخالي من البيانات 
        '   ويتم الخروج وعدم تنفيذ باقي الاكواد
        Dim c As Control
        For Each c In GroupBox1.Controls
            If TypeName(c) = "TextBox" Then
                If c.Text = "" Then
                    MsgBox(c.Name & " Is Empty Cant's Update", vbCritical)
                    c.Select()
                    Exit Sub
                End If
            End If
        Next

        ' نقوم بعمل اربعة متغيرات يأخذ كل منهم قيمة احد بيانات العميل
        Dim FirstName, LastName, Email, Mobile, x As String
        FirstName = ",'" & TextBox1.Text & "',"
        LastName = "'" & TextBox2.Text & "',"
        Email = "'" & TextBox4.Text & "',"
        Mobile = "'" & TextBox3.Text & "'"

        ' النص الذى سيدخل الي السجل وهو ارسال القيم السابقة الي الدالة 
        ' Cupdate
        ' وهي الدالة المسئولة عمل تحديث لبيانات العميل في قاعدة
        ' بيانات البنك فتأخذ القيم السابقة لبيانات العميل 
        ' ثم تقوم الدالة بالبحث عن العميل عن طريق رقم الايديه الخاص به 
        '  وهو في هذه الحالة سيكون في المتغير اي ثم تقوم بعمل 
        '  تحديث لبيانات هذا العميل فى حالة العثور عليه
        x = "Cupdate " & i & FirstName & LastName & Email & Mobile

        ' كود الاتصال بالدالة 
        rs.Open(x, cn)

        ' اظهار الرسالة تفيد تنفيذ التحديث
        MsgBox(rs("message").Value, MsgBoxStyle.Information, "Update")

        ' عمل اغلاق للاتصال 
        rs.Close()

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click

        ' كود الرجوع للصفحة الاولي
        Me.Dispose()

    End Sub
End Class