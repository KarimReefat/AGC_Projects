﻿Public Class Form4

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ' كود اغلاق الشاشة الخاصة بالايداع
        Me.Dispose()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        ' الكود المسئول عن التأكد من عدم 
        '  وجود مربعات نص خالية عندما يتم الضغط علي مفتاح حفظ
        Dim c As Control
        For Each c In GroupBox1.Controls
            If TypeName(c) = "TextBox" Then
                If c.Text = "" Then
                    MsgBox(c.Name & " Is Empty Cant's Save", vbCritical)
                    c.Select()
                    Exit Sub
                End If
            End If
        Next

        ' كود التأكد من ان الكمية المكتوبة قيمة رقمية وليست احرف او رموز اخري
        If IsNumeric(TextBox1.Text) = False Then
            MsgBox("The Ammount is Not Numeric")
            Exit Sub
        End If

        ' اولاً يتم اخذ قيمة الرقم ويتم اضافته الي خانة التفاصيل
        '  من النصوص بداخل مربعات النص ثم يتم بعد ذلك اضافة رقم الايدي
        '  الخاص بالعميل المراد اضافة رصيد اليه ويتم بعد ذلك ارسال كل 
        ' هذا الي الدالة نيو موفمينت وهي الدالة الخاصة بعملية زيادة الرصيد
        ' وهي نفس الدالة التى نقوم باستخدامها في حالة السحب من الرصيد مع 
        ' الاختلاف في طريقة الاستدعاء وطريقة كتابة المعاملات الخاصة بها 
        Dim x, amount, details As String
        amount = "@Deposits = " & TextBox1.Text
        details = "," & "@Details = " & "'" & TextBox2.Text & "'"
        x = "NewMovement " & i & "," & amount & details

        ' بعد ذلك يتم ارسال كل هذا الي السجل ار اس من اجل عمل تحديث البيانات
        rs.Open(x, cn)

        ' يتم اظهار الرسالة الى تعود بها الدالة للتأكد من صحة عملية زيادة الرصيد
        MsgBox(rs(0).Value)

        ' غلق الاتصال مع الجدول
        rs.Close()

        ' اغلاق الشاشة الخاصة بزيادة الرصيد
        Me.Dispose()

    End Sub

    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress

        ' الكود الخاص بتحويل المؤشر الي مربع النص
        ' التالي بعد ان يتم الضغط علي مفتاح انتر
        If e.KeyChar = Chr(13) Then
            TextBox2.Select()
        End If

    End Sub

    Private Sub TextBox2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox2.KeyPress

        ' الكود الخاص بتحويل المؤشر الي مربع النص
        ' التالي بعد ان يتم الضغط علي مفتاح انتر
        If e.KeyChar = Chr(13) Then
            Button2.Select()
        End If

    End Sub

    Private Sub Form4_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Disposed

        '  يتم فتح الاتصال مع جدول توتلاز من اجل الاستعلام 
        ' قيمة النقود في الحساب الخاص بالعميل 
        '  وتظهر هذه القيمة في مربع النص الخاص بها
        '  في شاشة بيانات العميل ويتم تنفيذ هذا الكود
        ' بعد ان يتم اغلاق الشاشة الخاصة بعمل ايداع في حساب العميل
        ' اي بعد ان يتم اضافة نقود الي الحساب يتم عمل تحديث لهذا الحساب
        ' لإظهار القيمة التى تمت اضافتها 
        rs1.Open("Select * From Totals where CustomerId = '" & i & "'", cn)

        ' يقوم الكود بالتأكد من انه قد تم العثور علي العميل 
        ' فيتم اظهار قيمة المبلغ الموجود بحساب هذا العميل 
        ' في مربع النص الخاص بالمبلغ وفى حالة عدم العثور عليه 
        ' يتم اظهار القيمة صفر
        If rs1.EOF Or rs1.BOF Then
            Form3.TextBox5.Text = "0"
        Else
            Form3.TextBox5.Text = rs1("Net").Value
        End If

        ' كود اغلاق الاتصال مع الجداول 
        rs1.Close()

    End Sub

    Private Sub Form4_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class