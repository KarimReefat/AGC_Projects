﻿Public Class Form2

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ' يتم وضع المؤشر علي مربع النص الاول عند تحميل الفورم
        TextBox1.Select()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        ' كود فتح الاتصال مع جدوال العملاء من اجل ادخال بيانات عميل جديد
        rs.CursorLocation = ADODB.CursorLocationEnum.adUseClient
        rs.CursorType = ADODB.CursorTypeEnum.adOpenDynamic
        rs.LockType = ADODB.LockTypeEnum.adLockOptimistic
        rs.Open("Customers", cn)

        ' الكود المسئول عن التأكد من عدم 
        '  وجود مربعات نص خالية عندما يتم الضغط علي مفتاح 
        ' حفظ سيف ويتم هنا اخذ نسخة من الادوات الموجودة داخل 
        ' الجروب الي المتغير سي ثم يتم فحص اولاً نوعية الاداة 
        ' عن طريق الدالة تايب نيم وبعد التأكد من ان نوع 
        '  الاداة هو مربع نص يتم التأكد من انها خالية من البيانات
        ' وفى تلك الحالة يتم اظهار رسالة تفيد بعدم امكانية الحفظ
        ' ويتم ايقاف المؤشر علي مربع النص الخالي من البيانات 
        '  ويتم اغلاق الاتصال مع الجدول ار اس ويتم الخروج وعدم تنفيذ باقي الاكواد
        Dim c As Control
        For Each c In GroupBox1.Controls
            If TypeName(c) = "TextBox" Then
                If c.Text = "" Then
                    MsgBox(c.Name & " Is Empty Cant's Save", vbCritical)
                    c.Select
                    rs.Close()
                    Exit Sub
                End If
            End If
        Next

        ' كود اضافة بيانات عميل جديد واظهار رسالة تفيد حفظ البيانات
        rs.AddNew()
        rs("FirstName").Value = TextBox1.Text
        rs("LastName").Value = TextBox2.Text
        rs("Mobile").Value = TextBox3.Text
        rs("Email").Value = TextBox4.Text
        rs.Update()

        ' الكود التالي يقوم بأخذ رقم الايديه للعميل الجديد
        ' ويقوم بوضع هذا الرقم في المتغير ايه من اجل التعامل معه
        ' يتم اظهار رسالة تفيد تمام الحفظ ورقم العميل الجديد من اجل التعامل معه
        rs.MoveLast()
        i = rs("ID").Value
        MsgBox("Saved And Your New Id is " & i, MsgBoxStyle.Information, "CustomerData")

        ' كود اغلاق الاتصال مع الجدول
        rs.Close()

        ' مجموعات الاكواد التالية ستؤدي الي حدوث بطء اثناء تنفيذ عملية
        ' اضافة عميل جديد ولكن كان لابد من ان اضيف هذه الاكواد بسبب حدوث 
        ' خطأ اثناء عمليات السحب او الايداع التى نقوم بها في الشاشة 
        ' الرابعة والخامسة من البرنامج وكان الخطأ الذى يحدث هو ان البرنامج 
        ' يقوم باظهار رسالة تفيد بأن حساب العميل المبلغ به يساوي صفر 
        ' وبدون دخول في الكثير من التفاصيل كان الحل لهذا الخطأ هو ان اقوم
        ' باضافة سجل في جدول حركة العملاء يكون هذا السجل يحمل رقم العميل 
        ' الجديد الذى قمت باضافته ويتم وضع قيمة صفرية في خانات الايداع 
        ' والسحب الخاص بهذا العميل ثم اقوم باغلاق الاتصال مع جدول حركة العملاء
        rs.CursorLocation = ADODB.CursorLocationEnum.adUseClient
        rs.CursorType = ADODB.CursorTypeEnum.adOpenDynamic
        rs.LockType = ADODB.LockTypeEnum.adLockOptimistic
        rs.Open("Actions", cn)
        rs.AddNew()
        rs("CustomerID").Value = i
        rs("Withdrawals").Value = 0
        rs("Deposits").Value = 0
        rs.Update()
        rs.Close()

        ' كود الخروج من الشاشة الحالية وينتج عنه ايضاً اخفاء البيانات السابقة من مربعات النص
        Me.Dispose()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        ' يتم عند الضغط علي مفتاح كانسيل تفريغ مربعات النص من النصوص التى بها
        Dim c As Control
        For Each c In GroupBox1.Controls
            If TypeName(c) = "TextBox" Then
                c.Text = ""
            End If
        Next

        ' الخروج من الفورم الحالية 
        Me.Dispose()

    End Sub

    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress

        ' الكود الخاص بمنع كتابة ارقام داخل مربع النص الخاص بالاسم الاول
        If IsNumeric(e.KeyChar) = True Then
            SendKeys.Send(Chr(8))
        End If

        ' الكود الخاص بتحويل المؤشر الي مربع النص
        ' التالي بعد ان يتم الضغط علي مفتاح انتر
        If e.KeyChar = Chr(13) Then
            TextBox2.Select()
        End If

    End Sub

    Private Sub TextBox2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox2.KeyPress

        ' الكود الخاص بمنع كتابة ارقام داخل مربع النص الخاص بالاسم الثاني
        If IsNumeric(e.KeyChar) = True Then
            SendKeys.Send(Chr(8))
        End If

        ' الكود الخاص بتحويل المؤشر الي مربع النص
        ' التالي بعد ان يتم الضغط علي مفتاح انتر
        If e.KeyChar = Chr(13) Then
            TextBox3.Select()
        End If


    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub TextBox3_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox3.KeyPress

        ' الكود الخاص بتحويل المؤشر الي مربع النص
        ' التالي بعد ان يتم الضغط علي مفتاح انتر
        If e.KeyChar = Chr(13) Then
            TextBox4.Select()
        End If

    End Sub

    Private Sub TextBox4_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox4.KeyPress
        ' الكود الخاص بتحويل المؤشر الي مربع النص
        ' التالي بعد ان يتم الضغط علي مفتاح انتر
        If e.KeyChar = Chr(13) Then
            Button2.Select()
        End If
    End Sub

    Private Sub TextBox4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox4.TextChanged

    End Sub
End Class