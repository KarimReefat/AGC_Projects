﻿Module Module1

    'الكود الخاص بتعريف الاصناف
    'الخاصة بتعريف بالاتصال بقاعدة
    'البيانات والجداول وجداول الاستعلام
    Public cn As New ADODB.Connection
    Public rs As New ADODB.Recordset
    Public rs1 As New ADODB.Recordset
    Public con As String = "Driver={SQL Server Native Client 10.0};Server=KARIM-PC\SQLEXPRESS;Database=Bank;Uid=dev1;Pwd=123;"
    Public i As Integer

    ' الدالة القادمة مسئولة عن الرجوع بالرقم الموجود بداخل نص
    ' فعندما نقوم بارسال اي نص الي الدالة تقوم الدالة باستخراج
    ' الارقام الموجودة بداخل هذا النص عن طريق حذف الرموز والحروف
    ' التى تكون موجودة بداخل النص والاحتفاظ بالارقام فقط بنفس 
    ' الترتيب الذى تم ادخاله بها في النص فمثلاً اذا قمت باعطاءها النص
    ' " t357s"*& \ 4" 
    ' القيمة الرقمية التى تعود بها الدالة هي 3574

    Public Function only_integer(ByVal a As String) As Integer
        Dim c As String
        Dim d As Char
        c = ""
        For Each d In a
            If IsNumeric(d) = True Then
                c = c + d
            End If
        Next
        only_integer = Val(c)
    End Function

End Module






