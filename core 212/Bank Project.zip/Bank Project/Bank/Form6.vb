﻿Public Class Form6
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        ' يتم فحص حالة الار اس واذا كانت متصلة بقاعدة البيانات 
        ' يتم اغلاق الاتصال 
        If rs.State = 1 Then
            rs.Close()
        End If

        ' يتم الخروج من شاشة التقارير
        Me.Dispose()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click

        ' الكود الخاص بغلق الاتصال مع الجدول
        If rs.State = 1 Then
            rs.Close()
        End If

        ' كود الاستعلام عن البيانات من جدول حركة العملاء
        rs.CursorLocation = ADODB.CursorLocationEnum.adUseClient
        rs.CursorType = ADODB.CursorTypeEnum.adOpenKeyset
        rs.Open("Select * From Actions", cn)

        ' كود توصيل الداتا جريد مع جدول الاستعلام
        AxDataGrid1.DataSource = rs
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click

        ' الكود الخاص بغلق الاتصال مع الجدول
        If rs.State = 1 Then
            rs.Close()
        End If

        ' كود الاستعلام عن البيانات من جدول العملاء
        rs.CursorLocation = ADODB.CursorLocationEnum.adUseClient
        rs.CursorType = ADODB.CursorTypeEnum.adOpenKeyset
        rs.Open("Select * From Customers", cn)

        ' كود توصيل الداتا جريد مع جدول الاستعلام
        AxDataGrid1.DataSource = rs
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        ' الكود الخاص بغلق الاتصال مع الجدول
        If rs.State = 1 Then
            rs.Close()
        End If

        ' كود الاستعلام عن البيانات من جدول التوتيل 
        rs.CursorLocation = ADODB.CursorLocationEnum.adUseClient
        rs.CursorType = ADODB.CursorTypeEnum.adOpenKeyset
        rs.Open("Select * From Totals", cn)

        ' كود توصيل الداتا جريد مع جدول الاستعلام
        AxDataGrid1.DataSource = rs
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click

        ' الكود الخاص بغلق الاتصال مع الجدول
        If rs.State = 1 Then
            rs.Close()
        End If

        ' كود الاستعلام عن البيانات من جدول التوتيل 2
        rs.CursorLocation = ADODB.CursorLocationEnum.adUseClient
        rs.CursorType = ADODB.CursorTypeEnum.adOpenKeyset
        rs.Open("Select * From Totals02", cn)

        ' كود توصيل الداتا جريد مع جدول الاستعلام
        AxDataGrid1.DataSource = rs
    End Sub

End Class