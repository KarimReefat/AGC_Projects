﻿Public Class Form2

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ' الكود المسئول عن اخفاء فورم 2 واظهار فورم 1 ويتم تنفيذه 
        '  تحت مفتاح عودة
        Me.Hide()
        Form1.Show()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        'الكود المسئول عن انهاء البرنامج يتم تنفيذه تحت مفتاح خروج 
        End
    End Sub

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' الكود المسئول عن اتصال اداة الداتا جريد بمصدر البيانات 
        ' بمصدر البيانات الخاص بها وهو في هذه الحالة سيكون الجدول 
        ' بيانات العملاء
        AxDataGrid1.DataSource = cu
    End Sub
End Class