﻿Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' يتم تنفيذ هذا الكود في حدث الفورم لود للشاشة الرئيسية للبرنامج ويقوم بعمل 
        ' فتح اتصال مع قاعدة البيانات واسمها ثم يقوم بعمل جعل المؤشر يبحث عن قاعدة 
        ' البيانات بداخل مجلد المشروع ثم نقوم باختيار اسم الجدول ونوع الفتح ونوع الغلق للجدولين
        cn.Open("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Bank.mdb;")
        ' الكود المسئول عن فتح الاتصال مع جدول بيانات العملاء واختيار نوع الفتح 
        cu.CursorLocation = ADODB.CursorLocationEnum.adUseClient
        cu.Open("Customers", cn, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockOptimistic)
        ' الكود المسئول عن فتح الاتصال مع جدول حركة العملاء واختيار نوع الفتح 
        mo.CursorLocation = ADODB.CursorLocationEnum.adUseClient
        mo.Open("Move", cn, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockOptimistic)
        ' الكود المسئول عن اغلاق مفاتيح الحفظ والحذف بداخل شاشة عميل جديد وشاشة حركة العملاء
        ' ولا يتم تفعيل هذه الاكواد الا من داخل مفتاح جديد ومفتاح استدعاء في كلتا الشاشتين
        Button2.Enabled = False
        Button3.Enabled = False
        Button16.Enabled = False
        Button17.Enabled = False
    End Sub

    Private Sub Button11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button11.Click
        ' يتم تنفيذ هذا الكود عند الضغط علي مفتاح اضافة عميل جديد 
        ' في الشاشة الرئيسية للبرنامج ويقوم بالانتقال الي شاشة اضافة عميل جديد
        TabControl1.SelectTab(1)
    End Sub

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button12.Click
        ' يتم تنفيذ هذا الكود تحت مفتاح حركة ايداع وسحب ويقوم بالانتقال الي التبويب الخاص بتلك الشاشة
        TabControl1.SelectTab(2)
    End Sub

    Private Sub Button13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button13.Click
        ' الكود الخاص باخفاء الشاشة الرئيسية واظهار شاشة التقارير 
        Form2.Show()
        Me.Hide()
    End Sub

    Private Sub Button14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button14.Click
        ' الكود الخاص بانهاء البرنامج
        End
    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        ' الكود المسئول عن عمل تحديث لسجلات جدول العملاء ثم يقوم باظهار رسالة 
        ' تفيد صحة الابديت ثم يقوم بعمل افراغ للبيانات من الحقول  ويتم تنفيذه عند الضغط علي مفتاح حفظ

        ' الكود المسئول عن التأكد من عدم خلو الحقول من البيانات فلابد وان يكون 
        '  كل حقل من الحقول بداخله بيانات وفي حالة عدم وجود بيانات 
        '  في حقل من الحقول يتم ظهور رسالة تفيد ذلك ولا يتم تنفيذ باقي الاكواد
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or
            TextBox4.Text = "" Or TextBox5.Text = "" Or TextBox6.Text = "" Or
            TextBox7.Text = "" Then
            MsgBox("هناك خانات لا يوجد بها بيانات")
            Exit Sub
        End If

        '  تقوم مجموعة الاكواد التالية بأخذ البيانات التى سيتم 
        '  تخزينها بداخل الحقول من خلال مربعات النص ويتم تخزينها 
        '  في داخل الجدول ويتم اخذ التاريخ من اداة الديت بيكر 
        ' بعد ذلك يتم عمل تحديث للجدول وتخزين البيانات التى توجد في هذه الحقول 
        '  ثم بعد ذلك يتم ظهور رسالة تفيد اتمام عملية الحفظ بنجاح
        cu("SName").Value = TextBox1.Text
        cu("ID").Value = TextBox2.Text
        cu("Address").Value = TextBox3.Text
        cu("Email").Value = TextBox4.Text
        cu("Phone").Value = TextBox5.Text
        cu("Mobile").Value = TextBox6.Text
        cu("PDate").Value = DateTimePicker1.Value
        cu("Notes").Value = TextBox7.Text
        cu.Update()
        MsgBox("saved")

        ' يقوم الكود التالي بتفعيل مفتاح جديد 
        ' ويقوم بايقاف تفعيل مفتاح حفظ بعد ان تتم عملية الحفظ بنجاح 
        ' لكي لا يتم الضغط علي المفتاح مرة اخري 
        Button1.Enabled = True
        Button2.Enabled = False

        ' الكود المسئول عن تفريغ مربعات النص من اية بيانات سابقة تكون موجودة بها بعد ان تتم عملية الحفظ
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        ' الكود المسئول عن حذف سجل من داخل جدول العملاء

        ' يقوم الكود التالية بالتأكد من ان المؤشر لا يقف علي بداية الجدول او نهاية الجدول 
        '  وفي الحالتين السابقتين لا يتم تنفيذ باقي الاجراء ويتم الخروج من الاجراء
        If cu.EOF = True Or cu.BOF = True Then
            Exit Sub
        End If

        ' الكود المسئول عن حذف السجل الحالي 
        cu.Delete()
        '  الكود المسئول عن القيام بعملية الاستعلام من اول وجديد 
        '  والسبب في ذلك لكي لا يظهر اي رسالة خطأ بسبب القيام بعملية الحذف لحقل قد تم الاشارة اليه علي انه في طريقه للحذف 
        ' فنقوم بعملية اعادة الاستعلام مرة اخري
        cu.Requery()

        ' نظهر رسالة تفيد تنفيذ عملية الحذف بنجاح 
        ' ثم يتم القيام بعملية حذف للبيانات التى بداخل السجلات
        MsgBox("Delete Complete")
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        ' كود عمل الاستدعاء من داخل جدول العملاء

        ' في حالة اذا لم يكن هناك سجلات بداخل الجدول
        ' اي اذا كان عدد السجلات يساوي صفر نقوم باظهار رسالة تفيد ذلك
        '  ولا يتم تنفيذ باقي الاكواد 
        If cu.RecordCount = 0 Then
            MsgBox("No Record")
            Exit Sub
        End If

        ' يتم التصريح بمتغير من نوع نص ثم 
        ' نقوم باظهار مربع نص يقوم المستخدم بادخال رقم الحساب فيه
        '  ثم بعد ذلك يتم الذهاب الي اول سجل في الجدول 
        ' نقوم بعمل استعلام عن رقم الحساب
        '  في حالة الوصول الي اخر سجل فهذا يعني انه لم يتم العثور علي السجل المطلوب 
        ' فيتم اظهار رسالة تفيد عدم العثور علي السجل ثم يتم ايقاف تفعيل مفتاح حذف والخروج وعدم تنفيد باقي الاكواد 
        Dim x As String
        x = InputBox("ادخل رقم الحساب")
        cu.MoveFirst()
        cu.Find("id = '" + x + "'")
        If cu.EOF Then
            MsgBox("Not Found")
            Button3.Enabled = False
            Exit Sub
        End If

        ' في حالة العثور علي السجل نقوم الاكواد التالية بأخذ القيم من داخل السجل واظهارها في مربعات النص وفي اداة التاريخ
        TextBox1.Text = cu("SName").Value
        TextBox2.Text = cu("ID").Value
        TextBox3.Text = cu("Address").Value
        TextBox4.Text = cu("Email").Value
        TextBox5.Text = cu("Phone").Value
        TextBox6.Text = cu("Mobile").Value
        DateTimePicker1.Value = cu("PDate").Value
        TextBox7.Text = cu("Notes").Value

        ' يتم اعادة تفعيل مفتاح الحذف في حالة العثور علي السجل المطلوب في حالة الرغبة في حذفه
        Button3.Enabled = True
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        ' الكود الذى يتم تنفيذه تحت مفتاح السابق للوصول الي السجل السابق
        ' يتم الذهاب الي السجل السابق وفي حالة اذا كان السجل السابق هو اول سجل داخل الجدول يتم اظهار رسالة تفيد ذلك ويتم الرجوع الي السجل السابق
        cu.MovePrevious()
        If cu.BOF Then
            MsgBox("The First Row", vbExclamation)
            cu.MoveNext()
            Exit Sub
        End If

        ' الكود المسئول عن اظهار البيانات بداخل مربعات النص عن طريق البيانات في الجدول
        TextBox1.Text = cu("SName").Value
        TextBox2.Text = cu("ID").Value
        TextBox3.Text = cu("Address").Value
        TextBox4.Text = cu("Email").Value
        TextBox5.Text = cu("Phone").Value
        TextBox6.Text = cu("Mobile").Value
        DateTimePicker1.Value = cu("PDate").Value
        TextBox7.Text = cu("Notes").Value
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        ' الكود المسئول عن الذهاب الي السجل التالي ويتم تنفيذه عند الضغط علي مفتاح التالي
        cu.MoveNext()
        ' في حالة الوصول الي اخر سجل في الجدول يتم اظهار رسالة تفيد ذلك ويتم ايقاف تنفيذ الاجراء
        If cu.EOF Then
            MsgBox("The Last Rows", vbExclamation)
            Exit Sub
        End If

        ' الكود المسئول عن اظهار البيانات في الحقول المختلفة
        TextBox1.Text = cu("SName").Value
        TextBox2.Text = cu("ID").Value
        TextBox3.Text = cu("Address").Value
        TextBox4.Text = cu("Email").Value
        TextBox5.Text = cu("Phone").Value
        TextBox6.Text = cu("Mobile").Value
        DateTimePicker1.Value = cu("PDate").Value
        TextBox7.Text = cu("Notes").Value
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        ' الكود المسئول عن اظهار اخر سجل في الجدول
        ' في حالة اذا كان عدد السجلات يساوي صفر يتم اظهار رسالة تفيد ذلك ويتم ايقاف باقي الاكواد
        If cu.RecordCount = 0 Then
            MsgBox("No Record")
            Exit Sub
        End If

        ' يتم الذهاب الي اخر سجل في الجدول 
        cu.MoveLast()

        ' يتم اظهار البيانات في الحقول المختلفة له 
        TextBox1.Text = cu("SName").Value
        TextBox2.Text = cu("ID").Value
        TextBox3.Text = cu("Address").Value
        TextBox4.Text = cu("Email").Value
        TextBox5.Text = cu("Phone").Value
        TextBox6.Text = cu("Mobile").Value
        DateTimePicker1.Value = cu("PDate").Value
        TextBox7.Text = cu("Notes").Value
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        ' كود الخروج من البرنامج
        End
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        ' كود اظهار شاشة الثانية للبرنامج
        Form2.Show()
        Me.Hide()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ' كود اضافة سجل جديد في جدول بيانات العملاء
        cu.AddNew()
        ' الكود المسئول عن تفريغ مربعات النص من البيانات
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
        ' يقوم الكود التالي بايقاف تفعيل مفتاح جيد ويتم تفعيل مفتاح حفظ بعد ذلك
        Button1.Enabled = False
        Button2.Enabled = True
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        ' كود الانتقال الي اول سجل في جدول بيانات العملاء
        ' في حالة عدم وجود سجلات في الجدول اي ان يكون عدد السجلات يساوي صفر
        ' يتم اظهار رسالة تفيد ذلك ويتم الخروج من الاجراء ولايتم تنفيذ باقي الاكواد
        If cu.RecordCount = 0 Then
            MsgBox("No Record")
            Exit Sub
        End If

        ' يتم الذهاب الي اول سجل في الجدول ويتم ادخال البيانات من السجل الحالي الي مربعات النص
        cu.MoveFirst()
        TextBox1.Text = cu("SName").Value
        TextBox2.Text = cu("ID").Value
        TextBox3.Text = cu("Address").Value
        TextBox4.Text = cu("Email").Value
        TextBox5.Text = cu("Phone").Value
        TextBox6.Text = cu("Mobile").Value
        DateTimePicker1.Value = cu("PDate").Value
        TextBox7.Text = cu("Notes").Value
    End Sub


    Private Sub ComboBox1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox1.Click
        ' الكود المسئول عن تحميل الكومبو في شاشة حركة العملاء باسماء العملاء
        ' ويتم تنفيذ هذا الكود عندما يتم الضغط علي قائمة اسماء العملاء
        ' يتم تفريغ اداة الكومبو من البيانات 
        ComboBox1.Items.Clear()
        ' يتم الذهاب او اول سجل في الجدول 
        cu.MoveFirst()

        ' الكود المسئول عن اضافة الحقول الي اداة الكومبو ويتم اضافة اسماء العملاء الموجودة في جدول بيانات العملاء
        Do While Not cu.EOF()
            ComboBox1.Items.Add(cu("SName").Value)
            cu.MoveNext()
        Loop
    End Sub

    Private Sub Button15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button15.Click
        ' كود اضافة سجل جديد في جدول حركة العملاء
        mo.AddNew()
        ' يتم تفريغ مربعات النص من البيانات ويتم تفريغ اداة الكومبو من البيانات بعد اضافة السجل الجديد
        ComboBox1.Items.Clear()
        TextBox8.Text = ""
        TextBox10.Text = ""
        TextBox11.Text = ""
        TextBox12.Text = ""

        ' يتم ايقاف تفعيل مفتاح جديد ويتم تفعيل مفتاح حفظ
        Button16.Enabled = True
        Button15.Enabled = False
    End Sub

    Private Sub Button16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button16.Click
        ' كود تسجيل بيانات السجل الجديد او تحديث البيانات في جدول حركة العملاء

        ' الكود المسئول عن التأكد من عدم خلو الحقول من البيانات وفي حالة اذا كان هناك احد الحقول خالي من البيانات 
        ' يتم اظهار رسالة تفيد ذلك ولا يتم تنفيذ باقي الاكواد
        If TextBox8.Text = "" Or TextBox10.Text = "" Or TextBox11.Text = "" Or
            TextBox12.Text = "" Then
            MsgBox("يوجد حقول فارغة من البيانات ")
            Exit Sub
        End If

        '  بعد التأكد من وجود جميع البيانات يتم ادخال البيانات في الحقول المختلفة في الجدول 
        ' ثم يتم عمل تحديث للسجلات بداخ الجدول واضافة البيانات الجديد
        '  ثم يتم اظهار رسالة تفيد تمام عملية التحديث
        mo("SName").Value = ComboBox1.SelectedItem
        mo("Id").Value = TextBox8.Text
        mo("ActionDate").Value = DateTimePicker2.Value
        mo("Payments").Value = TextBox11.Text
        mo("Out").Value = TextBox10.Text
        mo("Notes").Value = TextBox12.Text
        mo.Update()
        MsgBox("Saved", vbExclamation)

        ' يتم اخلاء السجلات من البيانات السابقة التى كانت بها 
        ' يتم اعادة تفعيل مفتاح جديد وايقاف تفعيل مفتاح حفظ 
        ComboBox1.Items.Clear()
        TextBox8.Text = ""
        TextBox10.Text = ""
        TextBox11.Text = ""
        TextBox12.Text = ""
        Button15.Enabled = True
        Button16.Enabled = False
    End Sub

    Private Sub Button17_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button17.Click
        ' الكود المسئول عن عملية حذف سجل من جدول حركة العملاء ويقوم باظهار رسالة في حالة عدم وجود سجلات
        ' يتم اولاً التأكد من وجود سجلات بداخل الجدول وانه لا يقف علي اول سجل او اخر سجل في الجدول
        If mo.RecordCount = 0 Or mo.EOF = True Or mo.BOF = True Then
            MsgBox("No Record")
            Exit Sub
        End If

        ' يتم تنفيذ عملية الحذف السجل الحالي ثم يتم اعادة الاستعلام مرة اخري 
        mo.Delete()
        mo.Requery()

        ' يتم تفريغ البيانات من مربعات النص واداة الكومبو بعد عملية الحذف
        ComboBox1.Items.Clear()
        ComboBox1.Text = ""
        TextBox8.Text = ""
        TextBox10.Text = ""
        TextBox11.Text = ""
        TextBox12.Text = ""
    End Sub

    Private Sub Button18_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button18.Click
        ' الكود المسئول عن الاستعلام عن طريق ادخال رقم الحساب 
        ' في حالة عدم وجود سجلات في الجدول يتم اظهار رسالة تفيد ذلك ثم يتم الخروج من البرنامج
        If mo.RecordCount = 0 Then
            MsgBox("No Record")
            Exit Sub
        End If

        ' يتم انشاء متغير ثم نظهر مربع نص ليتم ادخال رقم الحساب بداخله
        ' نقوم بعملية البحث عن رقم الحساب بعد ان يتم الذهاب الي اول سجل في الجدول
        ' في حالة عدم العثور علي رقم الحساب عن طريق الوصول الي اول سجل دون العثور عليه
        ' يتم اظهار رسالة تفيد ذلك ويتم ايقاف تفعيل مفتاح الحذف والخروج مع عدم تنفيذ باقي الاكواد
        Dim x As String
        x = InputBox("ادخل رقم الحساب")
        mo.MoveFirst()
        mo.Find("Id = '" + x + "'")
        If mo.EOF Then
            MsgBox("Not Found")
            Button17.Enabled = False
            Exit Sub
        End If

        ' في حالة العثور علي رقم الحساب يتم ادخال القيم من السجل الي مربعات النص واداة الكومبو
        ComboBox1.Text = mo("SName").Value
        TextBox8.Text = mo("Id").Value
        DateTimePicker2.Value = mo("ActionDate").Value
        TextBox11.Text = mo("Payments").Value
        TextBox10.Text = mo("Out").Value
        TextBox12.Text = mo("Notes").Value

        ' يتم اعادة تفعيل مفتاح الحذف في حالة الرغبة في حذف السجل الذى تم البحث عنه
        Button17.Enabled = True
    End Sub

    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox2.TextChanged
        ' الكود التالي يتم تنفيذه عندما يتم ادخال بيانات الي مربع النص 
        ' لأن مجموعة مربعات النص هذه لابد وان تكون الخانات التى بها يكون فيها ارقام فقط
        ' و في حالة ادخال حروف يتم اظهار رسالة تفيد ذلك ويتم حذف ما تم كتابته
        If Not IsNumeric(TextBox2.Text) Then
            MsgBox("لا يسمح الا بارقام في هذه الخانة")
            TextBox2.Text = ""
            Exit Sub
        End If
    End Sub

    Private Sub TextBox8_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox8.TextChanged
        ' الكود التالي يتم تنفيذه عندما يتم ادخال بيانات الي مربع النص 
        ' لأن مجموعة مربعات النص هذه لابد وان تكون الخانات التى بها يكون فيها ارقام فقط
        ' و في حالة ادخال حروف يتم اظهار رسالة تفيد ذلك ويتم حذف ما تم كتابته
        If Not IsNumeric(TextBox8.Text) Then
            MsgBox("لا يسمح الا بارقام")
            TextBox8.Text = ""
            Exit Sub
        End If
    End Sub

    Private Sub TextBox11_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox11.TextChanged
        ' الكود التالي يتم تنفيذه عندما يتم ادخال بيانات الي مربع النص 
        ' لأن مجموعة مربعات النص هذه لابد وان تكون الخانات التى بها يكون فيها ارقام فقط
        ' و في حالة ادخال حروف يتم اظهار رسالة تفيد ذلك ويتم حذف ما تم كتابته
        If Not IsNumeric(TextBox11.Text) Then
            MsgBox("لا يسمح الا بارقام")
            TextBox11.Text = ""
            Exit Sub
        End If
    End Sub

    Private Sub TextBox10_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox10.TextChanged
        ' الكود التالي يتم تنفيذه عندما يتم ادخال بيانات الي مربع النص 
        ' لأن مجموعة مربعات النص هذه لابد وان تكون الخانات التى بها يكون فيها ارقام فقط
        ' و في حالة ادخال حروف يتم اظهار رسالة تفيد ذلك ويتم حذف ما تم كتابته
        If Not IsNumeric(TextBox10.Text) Then
            MsgBox("لا يسمح الا بارقام")
            TextBox10.Text = ""
            Exit Sub
        End If
    End Sub
End Class
