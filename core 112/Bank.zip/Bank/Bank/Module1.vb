﻿Module Module1
    ' connection  الكود المسئول عن اخذ نسخة من الكلاس
    ' ونسختين من الكلاس
    ' recordset
    Public cn As New ADODB.Connection
    Public cu As New ADODB.Recordset
    Public mo As New ADODB.Recordset
End Module
